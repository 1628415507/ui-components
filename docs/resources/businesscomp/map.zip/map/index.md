<!--
 * @Description:
 * @Date: 2025-01-03 17:41:33
 * @LastEditTime: 2025-01-03 18:11:25
-->
<!--
## 地图

### 区划绘制&地理围栏

<ClientOnly>

::: example
resources/businesscomp/map/DrawMapDemo
:::

</ClientOnly>

### 车辆轨迹回放

<ClientOnly>

::: example
resources/businesscomp/map/TrackMapDemo
:::

</ClientOnly>

### 全程线路轨迹

<ClientOnly>

::: example
resources/businesscomp/map/RouteMapDemo
:::

</ClientOnly>

### 地图排线

<ClientOnly>

::: example
resources/businesscomp/map/AMapLayoutDemo
:::

</ClientOnly> -->
