/*
 * @Description:
 * @Date: 2024-01-09 15:05:49
 * @LastEditTime: 2024-01-09 15:49:14
 */
// export const AMAP_CONFIG = {
//     key: '351871ec560c6c34e9bbe14131d01696',
//     securityJsCode: 'eee454defe396cb372e260d7af55afd0'
// };
export const AMAP_CONFIG={
  key:'bf2b2192907b6eb2a0363dd9beb0aa60',
  securityJsCode:'0dadd5bc9a65f75344ee87d1e1dc5672',
}
// export const AMAP_CONFIG = {
//     key: '4fc82f35e6002d97b76e182e42df89ad',
//     securityJsCode: '8cb8dd0c6449b92542082d69f840af55'
// };
