import { default as ZInputNumber } from './components/form/input-number/src/index.vue';
import { default as ZInputDivider } from './components/form/input-divider/src/index.vue';
import { default as ZInputOrder } from './components/form/input-order/src/index.vue';
import { default as ZInputExpand } from './components/form/input-expand/src/index.vue';
import { default as ZAssociateSelect } from './components/form/associate-select/src/index.vue';
import { default as ZExpandMore } from './components/expand-more/src/index.vue';
import { default as ZInfoCard } from './components/info-card/src/index.vue';
import { default as ZPlusminusButton } from './components/plusminus-button/src/index.vue';
declare const _default: {
    install: any;
};
export default _default;
export { ZInputNumber, ZInputDivider, ZInputOrder, ZInputExpand, ZAssociateSelect, ZExpandMore, ZInfoCard, ZPlusminusButton };
