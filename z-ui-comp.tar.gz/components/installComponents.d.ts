import { Component, App } from 'vue';
export declare const components: {
    [propName: string]: Component;
};
export declare const installComponents: (app: App) => void;
