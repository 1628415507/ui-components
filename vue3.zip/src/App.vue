<!--
 * @Author: Hongzf
 * @Date: 2022-11-17 16:00:08
 * @LastEditors: Hongzf
 * @LastEditTime: 2022-12-01 17:13:08
 * @Description:
-->
<template>
  <router-view></router-view>
</template>
<script setup lang="ts"></script>

<style lang="scss" scoped></style>
