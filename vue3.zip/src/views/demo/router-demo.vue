<!--
 * @Author: Hongzf
 * @Date: 2022-11-21 09:54:25
 * @LastEditors: Hongzf
 * @LastEditTime: 2022-11-23 14:29:36
 * @Description:
-->
<template>
  <div>路由跳转测试</div>
</template>

<style scoped></style>
