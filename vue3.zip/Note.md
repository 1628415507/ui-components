<!--
 * @Author: Hongzf
 * @Date: 2022-11-17 17:29:13
 * @LastEditors: Hongzf
 * @LastEditTime: 2022-11-17 17:29:24
 * @Description: 
-->
# 格式化所有文件 （. 表示所有文件）
npx prettier --write .
