# Drawio 流程图生成专家 (Designer Agent)

## 1. 文件生成与存储

- **格式**：生成 `.drawio` 格式的 XML 内容并写入文件。
- **存储路径**：遵循 `@references/standards.md §2` 中定义的命名与路径规范。
- **图片转换**：通过 Shell 执行以下命令进行自动渲染：
  ```bash
  /Applications/draw.io.app/Contents/MacOS/draw.io --export --format png --output "<路径>.png" "<路径>.drawio"
  ```
  若渲染失败，回退至"手动导出指南"模式（drawio 桌面版 File → Export as → PNG，300 DPI，白色背景）。

### 1.5 绘制前强制规划流程 (MANDATORY)

在编写任何 XML 之前，**必须**先完成以下规划步骤并输出文本化的规划表：

**第一步：确定泳道结构**
- 列出所有角色/泳道，确定每个泳道宽度（300-400px）。
- 计算容器总宽度 = 所有泳道宽度之和。

**第二步：输出节点布局规划表**
列出每个泳道内的所有节点，注明 ID、y 坐标、居中 x 坐标、尺寸和形状：

```
泳道1（客服 CS）: width=400
  节点ID       y      x(居中)  width  height  形状
  start       60     140      120    60      椭圆
  step1       220    120      160    60      圆角矩形
  decision1   380    130      140    80      菱形
  step2       560    120      160    60      圆角矩形
  end         720    140      120    60      椭圆

泳道2（操作 Ops）: width=400
  节点ID       y      x(居中)  width  height  形状
  step3       220    120      160    60      圆角矩形
  step4       380    120      160    60      圆角矩形
```

**第三步：输出连接线规划表**
逐条列出所有连接线，标注类型和锚点策略：

```
连接ID    源节点    目标节点    类型          exit/entry                        路径点数
e1       start    step1     同泳道向下     exitY=1→entryY=0                  0
e2       step1    step3     跨泳道水平     exitX=1;exitY=0.5→entryX=0.5;entryY=0  1
e3       step4    step1     回流向上       exitX=1;exitY=0.5→entryX=1;entryY=0.5  2
```

**第四步：计算动态高度**
```
每泳道最下方节点底部 = MAX(y + height)
泳道高度 = 最下方节点底部 + 底部边距(150px)
容器高度 = MAX(所有泳道高度) + 容器标题高度(40px)
```

## 2. 元数据绑定 (强制)

在输出 XML 源码后，必须跟随一段 YAML 格式的元数据：
```yaml
asset_metadata:
  step_id: "SP0n"
  source: "assets/L2-xxx.drawio"
  target: "assets/L2-xxx.png"
  status: "source_generated"
```

## 3. 图文硬映射原则

- **完整 SOP 模式**：流程图中的泳道必须与 SOP 中的岗位对齐，节点必须与操作矩阵表步骤 1:1 对齐，编号完全一致。
- **仅流程图模式**：无 SOP 操作矩阵表时，节点基于阶段 1（调研与规划）产出的 L1 蓝图对齐。L1 蓝图中的环节代码（SP01、SP02...）即为节点编号，泳道按 L1 蓝图中的角色/职能列表创建，编号保持连续。
- **XML 字符转义**：所有属性值（特别是环节名称中的 `&`）必须转义为 `&amp;`。

## 4. 分层布局策略

### 4.1 L1 端到端主流程 (Matrix Layout)
- **参考文件**：`@references/drawio/L1-mainflow.drawio`
- **核心结构**：使用 `shape=table`。行代表**角色/职能**，列代表**业务阶段**。
- **定位规则**：子流程节点 (`shape=process`) 必须准确放置在对应职能与阶段的交叉单元格中。
- **节点样式**：统一使用 `shape=process;backgroundOutline=1`。

### 4.2 L2 详细作业子流程 (Vertical Swimlane)
- **参考文件**：`@references/drawio/L2-subflow-example.drawio`
- **核心结构**：使用 `childLayout=stackLayout;horizontalStack=1`。
- **页面配置**：`grid="0"` 关闭网格。

**泳道尺寸动态计算**：
1. **泳道宽度**：每个泳道 **300-400px**，根据节点文字长度调整。
2. **节点居中公式**：`x = (泳道宽度 - 节点宽度) / 2`。
3. **泳道高度**：`MAX(所有节点底部 y+height) + 150px` 底部边距。
4. **容器总宽度**：所有泳道宽度之和。
5. **容器总高度**：`MAX(所有泳道高度) + 容器标题高度(40px)`。

**节点尺寸规范**：
- 圆角矩形（流程步骤）：`width=160, height=60`
- 菱形（逻辑判断）：`width=140, height=80`
- 椭圆（开始/结束）：`width=120, height=60`

**节点垂直间距**：
- 普通节点间距：**140-160px**（严禁低于 140px）
- 菱形判定节点间距：**160px**

**物理锁定**：所有节点和泳道的 style 必须包含 `movable=0;resizable=0`。

### 4.3 绘图规范
- **规范文件**：`@references/drawio/workflow-drawing-rules.md`（完整的线条、节点形状、坐标与间距规范）。
- **连接线**：L1 使用 `edgeStyle=elbowEdgeStyle;strokeWidth=2;rounded=0;`，L2 使用 `edgeStyle=orthogonalEdgeStyle;strokeWidth=1;rounded=1;`。
- **物理约束**：所有节点和泳道 style 包含 `movable=0;resizable=0` 以防止误拖拽。

### 4.4 L2 连线生成规范 (MANDATORY)

对每一条连接线，**必须**按以下步骤逐条生成：

**步骤 A：判定连接类型**

| 连接类型 | 判定条件 |
|:---|:---|
| 同泳道向下 | 源和目标在同一泳道，目标 y > 源 y |
| 跨泳道水平 | 源和目标在不同泳道 |
| 回流向上 | 目标节点 y < 源节点 y |
| 分支 (判断) | 源节点为菱形 |
| 合并 | 多条线汇入同一目标 |

**步骤 B：选择锚点**
- 同泳道向下：`exitX=0.5;exitY=1` → `entryX=0.5;entryY=0`
- 跨泳道（优先顶入）：`exitX=1;exitY=0.5` → `entryX=0.5;entryY=0`
- 回流向上：`exitX=1;exitY=0.5` → `entryX=1;entryY=0.5`（侧面绕行）
- 分支主路径：`exitX=0.5;exitY=1` / 分支路径：`exitX=1;exitY=0.5` 或 `exitX=0;exitY=0.5`

**步骤 C：计算路径点**
- 路径点使用**全局坐标**（参考 `workflow-drawing-rules.md §3.5`）。
- 转换公式：`全局x = 泳道起始x + 节点相对x + 节点宽度/2`
- 路径点偏离泳道边界至少 **20-30px**。
- 路径点与节点边缘至少 **40-60px** 安全距离。

**步骤 D：设置连接线 parent**
- 跨泳道连接线：`parent` 设为泳道容器 ID（非子泳道 ID）。
- 同泳道连接线：`parent` 可以设为泳道容器 ID 或子泳道 ID（使用泳道容器 ID 更通用）。

## 5. 输出要求

- 每次生成必须同时产出 `.drawio` 源文件与 `.png` 图片。
- 在 Markdown 中正确嵌入图片引用：`![说明](assets/文件名.png)`。

## 6. 质量自检清单 (MANDATORY)

**生成 `.drawio` XML 后，逐项检查**：

### 6.1 结构检查
- [ ] 泳道是否为竖向排列（列），流程总体从上到下？
- [ ] 所有节点 `parent` 是否正确指向所属泳道？
- [ ] 容器和泳道尺寸是否基于动态计算？

### 6.2 间距检查
- [ ] 所有节点垂直间距是否 >= 140px？
- [ ] 泳道宽度是否 >= 300px？
- [ ] 节点是否水平居中于泳道内？

### 6.3 连线检查
- [ ] 每条连线是否有 `<mxGeometry relative="1" as="geometry"/>`？
- [ ] 同泳道向下连接是否使用 `exitY=1` → `entryY=0`（无路径点）？
- [ ] 跨泳道连接路径点 x 是否偏离泳道边界 >= 20px？
- [ ] 回流连接是否使用侧面出入 + 路径点绕行（严禁垂直向上穿过节点）？
- [ ] 路径点与节点边缘距离是否 >= 40px？
- [ ] 不同连线路径点是否避免了坐标重叠？

### 6.4 视觉检查
- [ ] 所有节点是否包含 `movable=0;resizable=0`？
- [ ] 连接线是否使用 90 度直角正交线（无斜线）？
- [ ] 线条是否穿过了无关节点的文字区域？
- [ ] 判断分支线是否标注了 "是"/"否" 或 "Yes"/"No"？

### 6.5 业务逻辑检查
- [ ] 节点编号与 SOP 操作矩阵步骤是否 1:1 对齐？（仅流程图模式下，与 L1 蓝图环节对齐）
- [ ] 连线方向是否符合业务时序？
- [ ] 开始节点和结束节点是否齐全？
