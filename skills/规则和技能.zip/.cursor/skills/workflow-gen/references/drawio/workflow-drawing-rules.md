---
tags: [绘图规范, drawio, 流程图, 货代]
created: 2026-03-08
updated: 2026-03-08
status: stable
---

# 用户需求用例 drawio 绘制规范 (极简路由版)

> [!important] 强制执行
> 本规范旨在消除流程图中冗余的“弯绕线”与“压节点”现象。绘制时必须遵循几何最短路径原则，严禁手动添加非必要的路径点。

## 1. 核心绘制原则 (Core Principles)

### 1.1 线条样式与路由策略
1. **风格区分 (Style Differentiation)**：
   - **L1 (一级主流程)**：强制使用 **肘形折线 (Elbow)**。
     - **跨列连接 (Horizontal Flow)**：`style="edgeStyle=elbowEdgeStyle;elbow=horizontal;rounded=0;strokeWidth=2;"`
     - **同列垂直连接 (Vertical Flow)**：`style="edgeStyle=elbowEdgeStyle;elbow=vertical;rounded=0;strokeWidth=2;"`
     - **兼容性要求 (No Node Overlap)**：如果肘形线路径穿过（压到）无关节点，**必须**：
       - a) 切换回 `edgeStyle=orthogonalEdgeStyle;` 开启自动避让；
       - b) 或显式添加 `<mxPoint>` 定义避让路径点。
   - **L2 (二级详细流程)**：强制使用 **正交折线 (Orthogonal)**。
     - `style="edgeStyle=orthogonalEdgeStyle;rounded=0;strokeWidth=2;jettySize=auto;orthogonalLoop=1;"`
2. **零路径点原则 (Zero Waypoints) - 基础**：
   - **推荐** 在简单连接（上下或左右相邻）中不添加 `<Array>`。
   - 让 Drawio 引擎根据 `exit` 和 `entry` 锚点自动计算正交路径。
3. **避让与逆流原则 (Bypass & Upstream) - 进阶**：
   - **避让节点**：当连接线必然穿过无关节点（压节点）时，**必须** 手动添加路径点 (`mxPoint`) 进行绕行。
   - **绕行路径**：优先选择侧向（右侧或左侧）空白区域，采用 `[侧出 -> 侧向拉远点 -> 侧入]` 模式。
   - **逆流连接**：若逻辑需要从下方节点连回上方节点（如“舱单提交”连回“报关”），必须从侧面引出，严禁垂直向上穿过中间节点。
4. **锚点自动测算**：
   - **上下连接**：若目标在源节点正下方，使用 `exitX=0.5;exitY=1` 到 `entryX=0.5;entryY=0`。
   - **左右连接**：若目标在源节点右侧，使用 `exitX=1;exitY=0.5` 到 `entryX=0;entryY=0.5`。
   - **避让/跨行连接**：使用“同侧侧出入”模式，即 `exitX=1;exitY=0.5` 到 `entryX=1;entryY=0.5`（结合路径点）。

### 1.2 节点布局规范
1. **对齐优先**：节点中心点必须严格落在网格线上。
2. **分支与判定 (Branching Logic)**：
   - 使用 **菱形节点 (Rhombus)** 表示逻辑判定。
   - `style="rhombus;whiteSpace=wrap;html=1;fillColor=#FFF2CC;strokeColor=#D6B656;"`
   - **路由策略**：主路径保持垂直向下 (`exitY=1` -> `entryY=0`)，分支路径采用水平引出 (`exitX=1;exitY=0.5` -> `entryX=0;entryY=0.5`)。
   - **判定标签**：在线条上显式添加 `value="Yes"` 或 `value="No"`。
3. **回流线规范 (Feedback Loops)**：
   - 严禁从节点底部反向连回上方。
   - 必须从侧面引出，经过至少一个 `mxPoint` 绕行，再接入上方节点的侧面。
4. **间距一致**：
   - 水平间距（跨泳道）：建议 150px - 200px。
   - 纵向间距（同泳道）：建议 100px - 140px。
5. **严禁压线**：节点之间必须留出至少 40px 的空白通道，供线条自动折返。
6. **节点形状区分 (L1 vs L2) - MANDATORY**：
   - **L1 (一级主流程)**：业务环节统一使用 **子流程 (Subprocess)** 形状：`style="shape=process;whiteSpace=wrap;html=1;backgroundOutline=1;rounded=0;"` (注意：严禁在 L1 使用 `fixedSize=1`)。
   - **L2 (二级详细流程)**：原子步骤统一使用 **圆角矩形 (Rounded Rectangle)**：`style="rounded=1;whiteSpace=wrap;html=1;"` (注意：严禁在 L2 使用 `shape=process`)。

---

## 2. 矩阵布局 (L1 Table) 优化规范

### 2.0 动态列宽与坐标对齐 (Dynamic Layout) - MANDATORY
1. **预计算宽度 (Algorithm)**：
   - **核心公式**：`Cell_Width = Max(Node_Width_in_Column) + 100px` (即：节点左右保留各 **50px** 的安全间距)。
   - **最小约束**：L1 过程节点 (`shape=process`) 必须设置 **最小宽度 180px，最小高度 60px**，最大宽度建议不超过 **220px**。
2. **预计算高度 (Algorithm)**：
   - **行高计算**：单元格内的所有节点（含 Start/End）上下均需保留 **40px** 的安全间距。
   - **Start/End 位点**：
     - `Start` 必须置于第一列第一行业务节点（如SP01 ）的 **正上方**，纵向间距 40px。
     - `End` 必须置于最后一列最后一行业务节点（如SP16 ）的 **正下方**，纵向间距 40px。
3. **坐标递增**：当某一列宽度调整时，后续所有列的 `x` 坐标必须累加。

### 2.1 消除背景干扰
1. **单一 Row 策略**：每个职能角色（如 Sales）仅创建一个 `tableRow`。
2. **透明 Cell 边框**：
   - 所有的 `tableCell` 必须设置 `strokeColor=none;` 以隐藏角色内部的细横线。
   - **示例样式**：`style="shape=tableCell;align=left;verticalAlign=top;strokeColor=none;fillColor=none;container=1;"`

### 2.2 节点归属
- 节点必须作为 `tableCell` 的子级（`parent="cell_id"`），坐标使用相对于 Cell 的偏移量。

### 2.3 矩阵连线协议 (Matrix Connection Protocol) - MANDATORY
1. **边界节点 (Boundary Nodes)**：L1 矩阵必须包含“开始”与“结束”节点，使用椭圆 (`ellipse`) 样式。
   - **开始节点**：置于第一行、第一列的业务单元格内。
   - **结束节点**：置于最后一行、最后一列的业务单元格内。
2. **Parent 绑定 (Critical)**：L1 矩阵中的所有 Edge **必须** 设置 `parent="table_container"`（即指向 table 容器的 ID），以确保能够穿透单元格并显示在容器图层之上。
3. **Geometry 强制闭合 (Critical)**：每一个 `edge="1"` 的 `mxCell` **必须** 包含一个 `<mxGeometry relative="1" as="geometry" />` 子元素。否则线条将无法显示。
4. **路由模式与锚点校准**：
   - **L1 连线协议 (Elbow)**：强制使用 `edgeStyle=elbowEdgeStyle;elbow=vertical;rounded=0;strokeWidth=2;`。
   - **水平流 (左右相邻)**：强制使用 `exitX=1;exitY=0.5` 到 `entryX=0;entryY=0.5`。
   - **跨行流 (侧出顶入)**：强制使用 `exitX=1;exitY=0.5` 到 `entryX=0.5;entryY=0`。
   - 示例样式：`style="edgeStyle=elbowEdgeStyle;elbow=vertical;rounded=0;strokeWidth=2;exitX=1;exitY=0.5;entryX=0.5;entryY=0;"`
5. **完整性约束**：生成的 XML 必须包含从 `node_1` 到 `node_n` 的全量逻辑链路，严禁断链。

---

## 3. 竖向泳道 (L2 Stack Layout) 规范

### 3.1 容器架构 (Container Architecture)

1. **强制使用 Stack Layout**：L2 必须使用一个总容器泳道，并配置 `childLayout=stackLayout;horizontal=1;horizontalStack=1;`。
2. **页面配置**：`grid="0"` 关闭网格，白色底色，无干扰线。
3. **锁定位置**：容器和泳道均设置 `movable=0;resizable=0;rotatable=0`。

**动态高度计算 (MANDATORY)**：
```
每个泳道内最下方节点底部 = MAX(该泳道内所有节点的 y坐标 + 节点高度)
泳道高度 = 最下方节点底部 + 底部边距 (100-200px)
泳道容器高度 = MAX(所有泳道高度)
页面高度 = 泳道容器y位置(40) + 泳道容器高度 + 底部边距(40-80px)
```

**XML 配置示例**：
```xml
<mxGraphModel dx="1422" dy="794" grid="0" gridSize="10"
              page="1" pageScale="1"
              pageWidth="动态计算" pageHeight="动态计算">
  <root>
    <mxCell id="0"/>
    <mxCell id="1" parent="0"/>

    <!-- 泳道容器 -->
    <mxCell id="swimlane-container" value="流程名称 (L2)"
      style="swimlane;startSize=40;horizontal=1;childLayout=stackLayout;horizontalStack=1;
             resizeParent=1;resizeParentMax=0;resizeLast=0;collapsible=0;
             movable=0;resizable=0;rotatable=0;
             swimlaneFillColor=#ffffff;strokeColor=#000000;"
      vertex="1" parent="1">
      <mxGeometry x="40" y="40" width="所有泳道宽度之和" height="动态计算" as="geometry"/>
    </mxCell>

    <!-- 子泳道 (竖向列) -->
    <mxCell id="lane1" value="角色名称"
      style="swimlane;startSize=40;horizontal=1;
             movable=0;resizable=0;rotatable=0;
             swimlaneFillColor=#DAE8FC;strokeColor=#6C8EBF;fontSize=14;"
      vertex="1" parent="swimlane-container">
      <mxGeometry x="0" y="40" width="泳道宽度" height="动态计算" as="geometry"/>
    </mxCell>
  </root>
</mxGraphModel>
```

### 3.2 节点规范 (Node Specification)

**所有节点必须**：指定 `parent` 为所属子泳道 ID，坐标 x/y 为相对泳道的坐标，统一加 `movable=0;resizable=0;fontColor=#000000`。

**节点尺寸**：
- 圆角矩形：宽度 **160px**，高度 **60px**
- 菱形：宽度 **140px**，高度 **80px**
- 椭圆：宽度 **120px**，高度 **60px**

**节点居中公式**：`x = (泳道宽度 - 节点宽度) / 2`

**泳道颜色与节点颜色 (莫兰迪色系)**：

| 角色 | 泳道背景 | 泳道边框 | 节点背景 | 节点边框 |
|:---|:---|:---|:---|:---|
| Sales (销售) | `#E1D5E7` | `#9673A6` | `#E1D5E7` | `#9673A6` |
| CS (客服) | `#DAE8FC` | `#6C8EBF` | `#DAE8FC` | `#6C8EBF` |
| Ops (操作) | `#D5E8D4` | `#82B366` | `#D5E8D4` | `#82B366` |
| Docs (单证) | `#FFF2CC` | `#D6B656` | `#FFF2CC` | `#D6B656` |
| Settlement (结算) | `#F8CECC` | `#B85450` | `#F8CECC` | `#B85450` |
| System (系统) | `#F5F5F5` | `#666666` | `#F5F5F5` | `#666666` |
| Overseas (海外代理) | `#F5F5F5` | `#666666` | `#F5F5F5` | `#666666` |

**特殊节点颜色**：

| 节点类型 | 形状 | 背景色 | 边框色 |
|:---|:---|:---|:---|
| 开始/结束 | 椭圆 `ellipse` | `#D5E8D4` | `#82B366` |
| 判断 | 菱形 `rhombus` | `#FFF9C4` | `#F57C00` |
| 成功/通过 | 圆角矩形 | `#C8E6C9` | `#388E3C` |
| 拒绝/错误 | 圆角矩形 | `#F8CECC` | `#B85450` |

**XML 节点示例**：
```xml
<!-- 普通流程节点 (圆角矩形) -->
<mxCell id="node1" value="节点文本"
  style="rounded=1;whiteSpace=wrap;html=1;fillColor=#DAE8FC;strokeColor=#6C8EBF;
         movable=0;resizable=0;fontColor=#000000;"
  vertex="1" parent="lane1">
  <mxGeometry x="居中x" y="节点y" width="160" height="60" as="geometry"/>
</mxCell>

<!-- 判断节点 (菱形) -->
<mxCell id="decision1" value="判断条件"
  style="rhombus;whiteSpace=wrap;html=1;fillColor=#FFF9C4;strokeColor=#F57C00;
         movable=0;resizable=0;fontColor=#000000;"
  vertex="1" parent="lane1">
  <mxGeometry x="居中x" y="节点y" width="140" height="80" as="geometry"/>
</mxCell>

<!-- 开始/结束节点 (椭圆) -->
<mxCell id="start" value="开始"
  style="ellipse;whiteSpace=wrap;html=1;fillColor=#D5E8D4;strokeColor=#82B366;
         movable=0;resizable=0;fontColor=#000000;"
  vertex="1" parent="lane1">
  <mxGeometry x="居中x" y="60" width="120" height="60" as="geometry"/>
</mxCell>
```

### 3.3 连线分类与锚点策略 (Edge Classification)

L2 连接线统一样式：`edgeStyle=orthogonalEdgeStyle;strokeWidth=1;rounded=1;`

**必须逐条分析每条连接线的类型，按以下分类选择连接策略**：

| 连接类型 | 判断标准 | exit/entry | 路径点 | XML 示例 |
|:---|:---|:---|:---|:---|
| 同泳道向下 | 源和目标在同一泳道，目标在下方 | `exitX=0.5;exitY=1` → `entryX=0.5;entryY=0` | 0 个 | 直接连接 |
| 跨泳道水平 | 源和目标在不同泳道 | `exitX=1;exitY=0.5` → `entryX=0.5;entryY=0` (优先顶入) | 最多 1-2 个 | 先水平后垂直 |
| 回流向上 | 目标节点在源上方 | `exitX=1;exitY=0.5` → `entryX=1;entryY=0.5` (同侧侧出入) | 2-3 个 | 侧出→纵向→侧入 |
| 分支 (判断) | 从判断节点分出多条路径 | 主路径 `exitX=0.5;exitY=1`，分支 `exitX=1;exitY=0.5` 或 `exitX=0;exitY=0.5` | 视情况 | 使用 value="是"/"否" |
| 合并 | 多条路径汇入同一目标 | 使用不同 entryX 区分 (`entryX=0.25` / `entryX=0.75`) | 视情况 | 避免连线重叠 |

**连接点优先顺序**：
1. 同泳道向下：`exitY=1` → `entryY=0`
2. 跨泳道向右（优先顶入）：`exitX=1;exitY=0.5` → `entryX=0.5;entryY=0`
3. 跨泳道向左（优先顶入）：`exitX=0;exitY=0.5` → `entryX=0.5;entryY=0`
4. 回流向上：使用侧面出入 + 路径点绕行

**核心原则**：同一节点的进入线条和离开线条必须使用不同的连接点（不同边或不同位置），使用 `entryDx=0;entryDy=0` 和 `exitDx=0;exitDy=0` 明确连接点位置。

**XML 连接线示例**：
```xml
<!-- 同泳道向下：0个路径点 -->
<mxCell id="e1" edge="1" source="nodeA" target="nodeB"
  style="edgeStyle=orthogonalEdgeStyle;strokeWidth=1;rounded=1;
         exitX=0.5;exitY=1;entryX=0.5;entryY=0;">
  <mxGeometry relative="1" as="geometry"/>
</mxCell>

<!-- 跨泳道连接：1个路径点，顶部进入 -->
<mxCell id="e2" edge="1" source="nodeA" target="nodeB"
  style="edgeStyle=orthogonalEdgeStyle;strokeWidth=1;rounded=1;
         exitX=1;exitY=0.5;entryX=0.5;entryY=0;entryDx=0;entryDy=0;"
  parent="swimlane-container">
  <mxGeometry relative="1" as="geometry">
    <Array as="points">
      <mxPoint x="目标节点全局中心x" y="源节点全局中心y"/>
    </Array>
  </mxGeometry>
</mxCell>

<!-- 回流连接：2个路径点，侧面绕行 -->
<mxCell id="e3" value="标签" edge="1" source="nodeB" target="nodeA"
  style="edgeStyle=orthogonalEdgeStyle;strokeWidth=1;rounded=1;
         exitX=1;exitY=0.5;entryX=1;entryY=0.5;entryDx=0;entryDy=0;"
  parent="swimlane-container">
  <mxGeometry relative="1" as="geometry">
    <Array as="points">
      <mxPoint x="泳道右侧+30" y="源节点全局y"/>
      <mxPoint x="泳道右侧+30" y="目标节点全局y"/>
    </Array>
  </mxGeometry>
</mxCell>
```

### 3.4 垂直对齐与间距 (Vertical Alignment - MANDATORY)

1. **泳道宽度**：每个泳道 **300-400px**（根据节点文字长度调整），总宽度 = 泳道数 x 单泳道宽度。
2. **起止点定位**：
   - `Start` 节点：`y = 60`（固定偏置）。
   - `End` 节点：最后一个业务节点 `y + 160`。
3. **节点垂直间距 (MANDATORY)**：
   - 普通节点间距：**140-160px**（确保连线有足够空间，严禁低于 140px）。
   - 菱形判定节点间距：**160px**。
4. **节点水平居中**：`x = (泳道宽度 - 节点宽度) / 2`。
5. **空白通道预留**：节点左右各留 `(泳道宽度 - 节点宽度) / 2` 的空白区域，供跨泳道连线通行。

### 3.5 坐标系规范 (Coordinate System)

drawio 使用两套坐标系，混淆是连线歪扭的主要原因：

1. **节点坐标（相对泳道）**：节点 `<mxGeometry>` 的 x/y 是相对于所属泳道左上角的偏移。
2. **路径点坐标（全局坐标）**：连接线 `<mxPoint>` 的 x/y 是相对于 `swimlane-container` 左上角的绝对坐标。

**转换公式**：
```
全局 x = 泳道起始 x + 泳道内节点相对 x + 节点宽度/2 (取中心)
全局 y = 泳道起始 y + 泳道内节点相对 y + 节点高度/2 (取中心)
```

**示例**：
- 泳道2 起始位置：x=400, y=40（y=40 是容器 startSize 偏移）
- 节点 step7 在泳道2 内：x=120, y=760, width=160, height=60
- step7 中心全局坐标：x = 400+120+80 = 600, y = 40+760+30 = 830

### 3.6 路径点优化原则 (Waypoint Optimization)

1. **最小化路径点数量**：简单连接 0 个，跨泳道最多 1-2 个，回流最多 2-3 个。
2. **避免泳道边界重合**：路径点 x 坐标不得设置在泳道边界上，应偏移至少 **20-30px**。例如泳道1 宽 400px，路径点 x 应为 377 而非 400。
3. **避免节点附近弯折**：路径点与目标节点连接点的距离应保持至少 **40-60px**。路径点 y 坐标应接近目标节点的连接点 y 坐标。
4. **避免线条重叠**：不同连接线的路径点不得共用相同坐标。
5. **精确定位**：复杂连接可使用 `<mxPoint x="xxx" y="xxx" as="targetPoint"/>` 精确定位。
6. **安全距离**：所有路径点与平行节点边线的距离保持至少 **40-60px**。

---

## 4. L2 绘制强制流程 (6 步)

### 步骤 1：节点布局规划 (MANDATORY)

在编写 XML 前，必须先输出节点布局规划表：

```
泳道1（角色名）：width=400
  节点ID       y      x(居中)  width  height  形状
  start       60     140      120    60      椭圆
  step1       220    120      160    60      圆角矩形
  decision1   380    130      140    80      菱形
  step2       540    120      160    60      圆角矩形
  ...

泳道2（角色名）：width=400
  节点ID       y      x(居中)  width  height  形状
  step3       220    120      160    60      圆角矩形
  ...
```

### 步骤 2：空白通道规划

1. **水平通道**（跨泳道连接）：节点间垂直间距 140-160px 的空白区域即为横向线条通道。
2. **垂直通道**（回流/绕行）：泳道内节点左右两侧的空白区域（`(泳道宽度-节点宽度)/2`）供纵向线条通行。

### 步骤 3：绘制泳道和节点

1. 按步骤 1 规划创建泳道容器和子泳道（设置 `movable=0;resizable=0`）。
2. 在每个泳道内按规划表创建节点（坐标使用相对泳道坐标）。

### 步骤 4：绘制连接线

对每一条连接线，执行以下判断流程：
1. 判定连接类型（参考 §3.3 分类表）。
2. 选择对应的 exit/entry 锚点。
3. 计算路径点坐标（使用全局坐标，参考 §3.5 转换公式）。
4. 路径点设置遵循 §3.6 优化原则。

### 步骤 5：质量自检 (MANDATORY)

- [ ] 泳道是否为竖向排列（列）？
- [ ] 流程方向是否总体从上到下？
- [ ] 节点垂直间距是否 >= 140px？
- [ ] 跨泳道连接线是否清晰，没有穿过无关节点？
- [ ] 每条连线在节点附近是否有不必要的弯折？（路径点 y 坐标是否接近目标连接点 y 坐标）
- [ ] 路径点是否远离节点边缘（>= 40px）？
- [ ] 路径点 x 是否偏离泳道边界（>= 20px 偏移）？
- [ ] 同一节点的进入和离开线条是否使用了不同连接点？
- [ ] 业务逻辑时序是否正确（如舱单先于报关）？
- [ ] 线条是否为 90 度直角正交线？

### 步骤 6：PNG 生成

```bash
/Applications/draw.io.app/Contents/MacOS/draw.io --export --format png --output "目标.png" "源.drawio"
```

若 CLI 不可用，回退至手动导出模式（drawio 桌面版 File → Export as → PNG，300 DPI，白色背景）。

---

## 5. 颜色与视觉识别 (莫兰迪色系)

保持 §3.2 中定义的角色颜色映射表。L1 与 L2 共享同一套莫兰迪色系，确保视觉一致性。

<!-- 
drawIO 连接线类型参考：
1. 直线 (Straight): edgeStyle=none; 最短路径，适合简单两点连接。
2. 正交折线 (Orthogonal): edgeStyle=orthogonalEdgeStyle; 自动 90 度避让，流程图最常用。
3. 肘形折线 (Elbow): edgeStyle=elbowEdgeStyle;elbow=vertical; 单拐点，适合 L1 矩阵。
-->