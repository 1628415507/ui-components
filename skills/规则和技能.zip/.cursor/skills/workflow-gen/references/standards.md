---
tags: [SOP, 标准, 货代, 规范]
description: 国际货代 SOP 生成技能的单一事实来源 (SSoT)，定义所有质量标准、格式契约与绘图规范。
version: 1.0.0
---

# 国际货代 SOP 金标参考标准 (REFERENCE STANDARDS)


> [!important] 核心原则
> 本文档是 `biz-workflow-gen` 技能的唯一事实来源。所有子 Agent (Planner, Writer, Generator, Auditor) 必须严格遵守此标准，确保输出的一致性。

## 1. 业务流程标准 (Process Standards)

### 1.1 一级业务流程 (L1 Primary Process)
- **矩阵布局原则 (Role x Phase)**：
    - **横轴 (X-Axis)**：业务阶段 (Phases)，标准 6 阶段模型。
    - **纵轴 (Y-Axis)**：职能角色 (Roles)，比如：从上到下按优先级Sales > CS > Ops > Docs > Settlement。
- **金标 9 列矩阵表**：
  `| 环节代码 | 航段 | 业务阶段 (Phase) | 环节名称 | 类型 | 执行岗位 | 核心动作说明 (原子化) | 输入单据 | 输出单据 |`
- **类型定义 (Mandatory)**：
    - **子流程 (Subprocess)**：需生成后续 L2 详解及垂直泳道图。
    - **操作节点 (Atomic Task)**：仅在 L1 展示，无需 L2。
- **标题规范 (Mandatory)**：
    - 文档顶部必须包含主标题：`[项目名称] 国际海运出口操作流程 L1 主流程` (加粗，20pt)。
- **Mermaid 预览规范**：
    - 使用 `graph LR`。
    - “子流程”使用 `[[SP0n 环节名称]]`。
    - “操作节点”使用 `[SP0n 环节名称]`。
    - **严禁**在 L1 流程图中重复标注角色名称（如 `(角色)`），因为已有横向泳道。
    - 必须使用 `subgraph` 按 Phase 划分列。

### 1.2 二级业务流程详解 (L2 Secondary Process)
- **六大金标模块结构**：
    1. **4.n.1 密度指标对齐 (Metrics Alignment)**：含术语对齐、系统字段映射、决策分支 (IF-THEN)。
    2. **4.n.2 操作矩阵表 (Atomized Ops Table)**：必须采用 6 列格式：
       `| 步骤 | 执行岗位 | 动作说明 | 系统/模块 | 关键录入/校验项 | 对接/交互方 |`
    3. **4.n.3 二级详细流程图 (Mermaid)**：强制使用 `graph TD` 垂直泳道。
    4. **4.n.4 关键控制点 (Control Points)**：系统强管控 (Hard-stops) 与合规风控。
    5. **4.n.5 异常处理与升级路径 (Exceptions)**：至少 3 个异常场景。
    6. **4.n.6 角色痛点分析 (AI Insight)**：效能瓶颈与 AI 提效建议。

### 1.3 核心业务时序与合规硬卡点 (Sequence & Compliance Hard-stops)

> [!important] 动态对齐原则
> 具体的业务先决条件 (Hard Gates) 必须以 `references/knowledge/` 下对应的领域知识文件为单一事实来源。

- **硬性审计协议**：
    - **Audit Loop**: 审计 Agent 必须将生成的 SOP 步骤与对应领域知识文件中的 `先决条件 (Hard Gate)` 进行 1:1 对比。
    - **时序纠偏**: 若 SOP 描述的行为早于其先决条件的完成（例如：未获预配即报关），必须标记为 [REJECT]。

## 2. 资产一致性与命名契约 (Naming & Consistency)

- **项目根目录**：`output/{{项目名称}}_{{YYYY-MM-DD}}/`
- **资产存放**：图片与 `.drawio` 存放于 `assets/` 目录。
- **命名规范**：
    - **主文档**：必须以 `操作流程SOP.md` 结尾。
    - **L1 绘图**：`L1-mainflow.drawio` / `L1-mainflow.png`。
    - **L2 绘图**：`L2-step{n}-{章节编号}-SP0n-{环节标题}.drawio` (空格换成 `-`)。
- **图片引用**：`![说明](assets/文件名.png)`。

## 3. Drawio 绘图物理规范 (Visual & Geometry)

### 3.1 颜色系统 (莫兰迪色系)
- **Sales (销售)**：`#e1d5e7` (淡紫) / Stroke: `#9673a6`
- **CS (客服)**：`#dae8fc` (淡蓝) / Stroke: `#6c8ebf`
- **Ops (操作)**：`#d5e8d4` (淡绿) / Stroke: `#82b366`
- **Docs (单证)**：`#fff2cc` (淡黄) / Stroke: `#d6b656`
- **Settlement (结算)**：`#f8cecc` (淡红) / Stroke: `#b85450`
- **Overseas (海外代理)**：`#f5f5f5` (浅灰) / Stroke: `#666666`
- **Header/Phase**：`#dae8fc` (加粗)
- **Decision (判定)**：`#fff9c4` (菱形)

### 3.2 布局几何契约 (Physical Geometry)
- **L1 矩阵计算公式 (Mandatory)**：
    - **动态网格尺度**：列数 = `Phases数量 + 1` (Label列)；行数 = `Roles数量 + 1` (Header行)。
    - **Cell 宽度**：`Cell_Width = Max(Node_Width_in_Column) + 120px`（左右各留 60px 间距）。
    - **1:1 物理网格原则 (Mandatory)**：每一行 (`tableRow`) 必须包含与 `Phases` 数量完全一致的独立单元格 (`tableCell`)。**严禁为了简化 XML 而合并相邻的空白单元格**，否则会导致网格线断裂。
    - **Cell 高度**：`Cell_Height = Max(Node_Count_in_Cell * 80) + 60px`（垂直间距不小于 20px，严禁节点堆叠）。
    - **节点尺寸**：固定宽度 180px，高度 60px。
    - **画布尺度**：强制 `pageWidth="2400" pageHeight="1600"`。
    - **标题图层 (Layer Isolation)**：主标题必须独立于 Table 容器，设置 `parent="1"`，绝对坐标 `(x=1200, y=20)`。
    - **岗位标签 (Horizontal Labels)**：第一列单元格内，必须通过独立的 `text` 节点实现岗位名称显示，设置 `horizontal=1;align=center;verticalAlign=middle;`，严禁使用 tableRow 自带旋转 value。

### 3.3 XML 关键属性与样式契约 (Gold Standard XML Styles)

为了确保资产 100% 对标金标模板，必须严格使用以下样式 ID 和属性：

- **L1 Table 容器** (table_container):
  `shape=table;childLayout=tableLayout;startSize=0;strokeColor=#000000;fillColor=#f5f5f5;fixedRows=1;fixedCols=1;container=1;collapsible=0;strokeWidth=1;`
- **L1 Table 行** (tableRow):
  `shape=tableRow;horizontal=1;startSize=0;fillColor=none;strokeColor=#000000;` (严禁在行级别设置 `fillColor`，以确保“空白泳道”效果)。
- **L1 Table 单元格** (tableCell):
  - **标题/表头单元格** (Phase Header): `shape=tableCell;align=center;verticalAlign=middle;strokeColor=#000000;fillColor=#dae8fc;fontStyle=1;`
  - **职能标签单元格** (Role Label): `shape=tableCell;align=center;verticalAlign=middle;strokeColor=#000000;fillColor=[RoleColor];fontStyle=1;`
  - **业务节点容器单元格** (Functional Cell): `shape=tableCell;align=left;verticalAlign=top;strokeColor=#000000;fillColor=#ffffff;container=1;` (必须显式设为 `#ffffff` 以确保背景为纯白，开启 `container=1` 以支持节点绝对定位)。
- **样式冲突规则**：如果 `tableRow` 和 `tableCell` 都设置了颜色，必须以 `tableCell` 的局部填充为准。业务区单元格必须显式填充为白色 (`#ffffff`)。
- **XML 字符转义**：生成的 XML 源码中，所有属性值（特别是环节名称中的 `&`）必须转义为 `&amp;`。

### 3.4 连接线样式与锚点契约 (Edge Styles & Anchors)

- **L1 连接线样式 (Mandatory)**：
    - **粗细**：强制使用 `strokeWidth=2;` 以区别于 L2。
    - **路由**：优先使用 `edgeStyle=elbowEdgeStyle;elbow=vertical;` 或 `edgeStyle=orthogonalEdgeStyle;`。
    - **圆角**：`rounded=0;` (直角风格)。
    - **父级等效性**：必须设置 `parent="table_container"` 以穿透单元格层级显示。
- **L2 连接线样式 (Mandatory)**：
    - **粗细**：强制使用 `strokeWidth=1;`。
    - **路由**：始终使用 `edgeStyle=orthogonalEdgeStyle;`。
    - **圆角**：`rounded=1;` (圆角风格)。

### 3.5 L2 页面与节点物理约束 (L2 Physical Constraints)

- **页面配置 (Mandatory)**：L2 流程图的 `<mxGraphModel>` 必须设置 `grid="0"` 关闭网格线。
- **节点锁定 (Mandatory)**：所有 L2 节点的 style 必须包含 `movable=0;resizable=0;fontColor=#000000`，防止误拖拽和字色不一致。
- **泳道锁定 (Mandatory)**：所有 L2 泳道容器和子泳道的 style 必须包含 `movable=0;resizable=0;rotatable=0`。
- **节点垂直间距**：普通节点间距 >= **140px**，菱形判定节点间距 >= **160px**。严禁低于此阈值。
- **泳道宽度**：每个子泳道最小宽度 **300px**，建议 **300-400px**。
- **节点尺寸**：圆角矩形 `160x60`，菱形 `140x80`，椭圆 `120x60`。
- **坐标系区分**：节点 `<mxGeometry>` x/y 为相对泳道坐标，连接线 `<mxPoint>` x/y 为全局坐标。详见 `@references/drawio/workflow-drawing-rules.md §3.5`。

- **标准 6 阶段 (Phase Taxonomy)**：
    1. 询价与接单 (Inquiry & Order)
    2. 订舱与准备 (Booking & Prep)
    3. 申报与放行 (Filing & Release)
    4. 单证与干线 (Docs & Mainhaul)
    5. 到港与交付 (Arrival & Delivery)
    6. 结算与结案 (Settlement & Closure)
- **拓扑前置条件**：
    - 出口报关前必须有舱单发送回执。
    - 美国线 ISF/AMS 必须在装船前 24h 提交。
    - 提单签发前必须录入所有应收应付费用。
