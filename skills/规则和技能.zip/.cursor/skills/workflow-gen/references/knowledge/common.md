# 货代业务领域知识 — 公共参考

> 跨运输模式通用的术语、岗位、结算、合规知识。所有业务专属参考文件共享此公共基础。

---

## 1. 核心术语体系

### 1.1 运输模式术语

| 缩写 | 英文全称 | 中文名称 | 说明 |
|---|---|---|---|
| FCL | Full Container Load | 整箱 | 一个集装箱仅装一个托运人的货物 |
| LCL | Less than Container Load | 拼箱 | 多个托运人共用一个集装箱 |
| CFS | Container Freight Station | 集装箱货运站 | 拼箱货的装拆箱作业场所 |
| CY | Container Yard | 集装箱堆场 | 整箱货的交接场所 |
| FBA | Fulfillment by Amazon | 亚马逊物流 | 卖家将货物发送到亚马逊仓库代为配送 |
| FTL | Full Truck Load | 整车 | 卡车运输中一车只装一票货 |
| LTL | Less than Truck Load | 零担 | 卡车运输中多票货拼车 |
| ULD | Unit Load Device | 集装器/航空板 | 空运中用于装载货物的标准容器 |
| TEU | Twenty-foot Equivalent Unit | 标准箱 | 20 英尺集装箱当量单位 |
| FEU | Forty-foot Equivalent Unit | 大柜 | 40 英尺集装箱当量单位 |

### 1.2 单证术语

| 缩写 | 英文全称 | 中文名称 | 说明 |
|---|---|---|---|
| MBL | Master Bill of Lading | 船东提单/主提单 | 船公司签发给货代的提单 |
| HBL | House Bill of Lading | 货代提单 | 货代签发给发货人的提单 |
| AWB | Air Waybill | 空运提单 | 航空公司签发的货物运输合同 |
| MAWB | Master Air Waybill | 主运单 | 航空公司签发给货代的主运单 |
| HAWB | House Air Waybill | 分运单 | 货代签发给发货人的分运单 |
| S/O | Shipping Order | 订舱确认书/下货纸 | 船公司确认订舱的凭证 |
| S/I | Shipping Instruction | 装运指示 | 发货人给货代的装运要求 |
| VGM | Verified Gross Mass | 经核实的集装箱总重 | SOLAS 公约要求强制申报 |
| AMS | Automated Manifest System | 美国反恐舱单 | 美线货物必须提交的安全申报 |
| ENS | Entry Summary Declaration | 欧盟入境摘要申报 | 欧线货物的安全申报 |
| AFR | Advance Filing Rules | 日本提前申报规则 | 日线货物的安全申报 |
| ISF | Importer Security Filing | 进口安全申报 (10+2) | 美线进口商安全申报 |
| CO | Certificate of Origin | 原产地证 | 证明货物原产地的文件 |
| CI | Commercial Invoice | 商业发票 | 贸易双方的货物交易凭证 |
| PL | Packing List | 装箱单 | 货物包装明细 |
| D/O | Delivery Order | 提货单 | 目的港提货凭证 |
| CLP | Container Load Plan | 装箱计划 | 集装箱内货物的装载安排 |

### 1.3 费用术语

| 缩写 | 英文全称 | 中文名称 | 说明 |
|---|---|---|---|
| O/F | Ocean Freight | 海运费 | 承运人收取的海上运输费用 |
| THC | Terminal Handling Charge | 码头操作费 | 码头装卸集装箱的费用 |
| CFS Charge | CFS Charge | 拼箱操作费 | 拼箱货在 CFS 的装拆箱费用 |
| BAF | Bunker Adjustment Factor | 燃油附加费 | 因油价波动收取的附加费 |
| CAF | Currency Adjustment Factor | 币值调整附加费 | 因汇率波动收取的附加费 |
| PSS | Peak Season Surcharge | 旺季附加费 | 旺季运力紧张时收取的附加费 |
| GRI | General Rate Increase | 综合费率上涨 | 船公司定期调价 |
| D&D | Detention & Demurrage | 滞箱费和滞港费 | 集装箱超期使用和堆存费 |
| LSS | Low Sulphur Surcharge | 低硫燃油附加费 | IMO 2020 低硫令相关费用 |
| DOC | Documentation Fee | 文件费 | 制作和处理运输文件的费用 |
| FSC | Fuel Surcharge | 燃油附加费（空运） | 空运中因油价收取的附加费 |
| SCC | Security Surcharge | 安全附加费（空运） | 空运安全检查相关费用 |

### 1.4 保险术语

| 缩写 | 英文全称 | 中文名称 | 说明 |
|---|---|---|---|
| ICC-A | Institute Cargo Clauses A | 协会货物条款 A（一切险） | 覆盖范围最广的货运险种，承保一切外来风险 |
| ICC-B | Institute Cargo Clauses B | 协会货物条款 B（水渍险） | 承保火灾、爆炸、碰撞、恶劣天气等列明风险 |
| ICC-C | Institute Cargo Clauses C | 协会货物条款 C（平安险） | 仅承保重大事故（沉船/搁浅/火灾等） |
| W2W | Warehouse to Warehouse | 仓至仓 | 保险覆盖从发货仓库到收货仓库全程 |
| CIP | Cargo Insurance Premium | 货物保险费 | 投保人支付的保费 |
| — | General Average | 共同海损 | 海运特有，为全体利益而产生的牺牲/费用由各方分摊 |

### 1.5 贸易术语 (Incoterms 2020)

| 术语 | 全称 | 适用 | 风险转移点 |
|---|---|---|---|
| EXW | Ex Works | 全模式 | 卖方工厂/仓库 |
| FCA | Free Carrier | 全模式 | 交货给承运人时 |
| FAS | Free Alongside Ship | 仅海运 | 船边 |
| FOB | Free On Board | 仅海运 | 装上船时 |
| CFR | Cost and Freight | 仅海运 | 装上船时（卖方付运费） |
| CIF | Cost, Insurance and Freight | 仅海运 | 装上船时（卖方付运费+保险） |
| CPT | Carriage Paid To | 全模式 | 交货给承运人时 |
| CIP | Carriage and Insurance Paid To | 全模式 | 交货给承运人时 |
| DAP | Delivered at Place | 全模式 | 目的地（卸货前） |
| DPU | Delivered at Place Unloaded | 全模式 | 目的地（卸货后） |
| DDP | Delivered Duty Paid | 全模式 | 目的地（完税后） |

### 1.6 信控与风控术语

| 术语 | 英文 | 说明 |
|---|---|---|
| 信用审核 | Credit Check | 接单前对客户信用等级、历史付款记录的评估 |
| 信用额度 | Credit Limit | 系统设定的客户最大赊销额度 |
| 账龄 | Aging (AR Aging) | 应收账款逾期天数分布 |
| 逾期 | Overdue | 超出约定账期仍未付款的应收款项 |
| 坏账 | Bad Debt / Write-off | 确认无法收回的应收款项 |
| 信控冻结 | Credit Hold | 因逾期或超额冻结客户下单权限 |

### 1.7 数字化术语

| 缩写 | 英文全称 | 说明 |
|---|---|---|
| e-AWB | Electronic Air Waybill | IATA 推行的电子航空运单，取代纸质 AWB |
| e-CMR | Electronic CMR | 电子公路运输合同单证，与纸质 CMR 具有同等法律效力 |
| eTIR | Electronic TIR | 电子 TIR 通关册，可缩减过境时间达 80% |
| e-POD | Electronic Proof of Delivery | 电子签收凭证，含 GPS 坐标与签收照片 |
| PLACI | Preloading Advance Cargo Information | IATA 预装货物信息标准程序 (2026 第 7 版) |
| ACAS | Air Cargo Advance Screening | 美国 CBP 空运货物预筛系统 |
| eFTI | Electronic Freight Transport Information | 欧盟电子货运信息法规，强制数字化运输文件 |
| FWB | Freight Waybill Message (Cargo-XML) | IATA 标准的电子运单数据报文 |
| FHL | Freight House List (Cargo-XML) | IATA 标准的分运单报文 |

### 1.8 合规认证术语

| 缩写 | 英文全称 | 说明 |
|---|---|---|
| AEO | Authorized Economic Operator | 经认证的经营者，享受海关便利化措施 |
| C-TPAT | Customs-Trade Partnership Against Terrorism | 美国海关反恐伙伴计划 |
| ISPS | International Ship and Port Facility Security Code | 国际船舶和港口设施保安规则 |
| ADR | Accord Dangereux Routier | 欧洲公路危险品运输协定 |
| IMDG | International Maritime Dangerous Goods Code | 国际海运危险货物规则 |
| DGR | Dangerous Goods Regulations (IATA) | IATA 危险品运输规则 |

---

## 2. 岗位职责体系

### 2.1 完整岗位矩阵（大型一代货代）

| 岗位 | 核心职责 | 关键 KPI |
|---|---|---|
| **航线运力采购** | 与船公司/航司签订运价合约、管理舱位分配、监控运力利用率 | 采购成本率、舱位利用率、合约覆盖率 |
| **销售** | 客户开发、报价管理、合约谈判、客户关系维护 | 新客户数、收入目标、客户留存率 |
| **客服** | 订单受理、客户沟通、异常协调、满意度管理 | 响应时效、客户满意度、异常处理率 |
| **操作** | 订舱执行、拖车安排、报关协调、全程节点跟踪 | 准时率、操作差错率、单票处理时效 |
| **单证** | 提单制作/校对、签发、更改、退单管理 | 单证准确率、签发时效、更改率 |
| **调度** | 车辆调配、仓库协调、集港/集货安排、资源优化 | 调度准时率、资源利用率、成本控制 |
| **财务结算** | 费用录入、账单生成、应收应付管理、利润核算 | 回款率、账龄分布、利润率 |

### 2.2 中小型二代货代岗位简化

| 标准岗位 | 简化方式 | 说明 |
|---|---|---|
| 航线运力采购 | **取消** | 从上游一代或同行获取舱位报价 |
| 销售 | 保留 | 可能老板亲自负责大客户 |
| 客服 + 操作 | **合并** | 一人负责从接单到操作全流程 |
| 单证 | **由操作兼任** | 提单校对简化，依赖船公司网站操作 |
| 调度 | **简化** | 仅安排拖车，无独立调度团队 |
| 财务结算 | 保留 | 可能由行政/老板兼任 |

---

## 3. 结算规则体系

### 3.1 费用分类

| 分类 | 说明 | 示例 |
|---|---|---|
| **应收费用** | 向客户（发货人/收货人）收取 | 海运费、操作费、报关费、拖车费、文件费 |
| **应付费用** | 向供应商支付 | 船公司运费、报关行费用、拖车公司费用、港口费用 |
| **代收代付** | 代客户收付、不计入利润 | THC、查验费、目的港费用 |

### 3.2 利润核算

```
毛利润 = 应收费用总额 - 应付费用总额
净利润 = 毛利润 - 管理费用分摊
单票利润率 = 毛利润 / 应收费用总额 × 100%
```

### 3.3 结算周期

| 业务类型 | 常见结算方式 | 说明 |
|---|---|---|
| 货主客户 | 月结 30/60/90 天 | 大客户享受更长账期 |
| 同行客户 | 票结 / 月结 15 天 | 信用额度较紧 |
| 海外指定货 | 票结预付 | 风险较高，通常要求预付 |
| 船公司 | 票结 / 月结 | 按合约约定 |
| 拖车/报关 | 月结 15-30 天 | 按供应商合约 |

---

## 4. 合规法规要点

### 4.1 国际公约与法规

| 法规 | 适用范围 | 关键要求 |
|---|---|---|
| **SOLAS 公约** | 全球海运 | VGM 强制申报 |
| **ISM 规则** | 全球海运 | 船舶安全管理 |
| **AMS (24h Rule)** | 美线 | 装船前 24 小时提交舱单 |
| **ENS** | 欧线 | 装船前 24 小时提交入境摘要申报 |
| **AFR** | 日线 | 装船前 24 小时提交提前申报 |
| **ISF (10+2)** | 美线进口 | 进口商安全申报 |
| **IATA DGR** | 全球空运 | 危险品空运操作规则 |
| **IMO IMDG Code** | 全球海运 | 危险品海运操作规则 |
| **ADR** | 欧洲公路 | 公路危险品运输操作规则 |
| **TIR 公约** | 75 国跨境公路 | 简化过境通关，海关担保制度 |
| **CMR 公约** | 国际公路运输 | 公路货物运输合同与承运人责任 |

### 4.2 中国海关相关

| 要求 | 说明 |
|---|---|
| **报关单** | 进出口货物必须向海关申报 |
| **检验检疫** | 特定商品需进出口检验检疫 |
| **原产地证** | 优惠贸易协定下的关税减免凭证 |
| **外汇核销** | 出口收汇/进口付汇管理 |
| **加工贸易手册** | 来料/进料加工的海关监管账册 |
| **AEO 认证** | 经认证的经营者，享受海关便利措施 |

---

## 5. 运输装载设备规格

### 5.1 海运集装箱规格 (Ocean Containers)

海运集装箱注重标准化和多功能性。载重受限于起运地/目的地的道路限重及码头吊机能力。

| 柜型 | 外尺寸（长×宽×高） | 内容积 | 载重（约） | 特点 |
|---|---|---|---|---|
| 20'GP | 6.06m × 2.44m × 2.59m | 33.2 CBM | 18-21 T | 通用小柜，适合重货 |
| 40'GP | 12.19m × 2.44m × 2.59m | 67.7 CBM | 22-26 T | 通用大柜，适合轻泡货 |
| 40'HC | 12.19m × 2.44m × 2.90m | 76.3 CBM | 22-26 T | 高柜，比 GP 高 1 英尺，最常用 |
| 45'HC | 13.72m × 2.44m × 2.90m | 86.0 CBM | 22-25 T | 特大高柜，北美/跨境电商常用 |
| 20'RF | 6.06m × 2.44m × 2.59m | 28.3 CBM | 18-21 T | 冷藏箱，带温控系统 |
| 40'RF | 12.19m × 2.44m × 2.59m | 59.3 CBM | 22-26 T | 冷藏大箱 |
| 20'OT | 6.06m × 2.44m × 2.59m | 32.5 CBM | 21.5 T | 开顶柜，适合超高机械 |
| 40'FR | 12.19m × 2.44m × 2.59m | N/A | 39.0 T | 框架柜，适合超宽/超重件 |

### 5.2 铁运集装箱规格 (Railway Containers)

中欧班列/铁运主要使用 **40'HC** 作为标准箱型。铁运对重量限制非常严格，超重会导致扣货、罚款甚至影响行车安全。

| 柜型 | 内容积 | 建议载重 (Cargo Weight) | 备注 |
|---|---|---|---|
| 20'GP (铁运) | 33.0 CBM | ≤ 20 T | 铁运较少使用 20 柜，通常需两小柜对拼发运 |
| 40'HC (铁运) | 76.0 CBM | 20 - 26 T | **铁运主力柜型**。超过 26 吨视为超重，需申请特批 |
| 45'HC (铁运) | 86.0 CBM | ≤ 22 T | 部分线路支持，主要针对电商大票货 |

**铁运载重注意事项**：
- **单箱重量**：通常货物重量建议控制在 26 吨以内，部分平台支持加收超重费发运至 28 吨。
- **配重平衡**：铁运极其注重箱内重心位置，左右偏差不能超过 10cm，前后不能超过 3:1。
- **SOC 柜**：铁运常使用自有箱 (Shipper Owned Container)，需符合铁路技术联运要求。

### 5.3 空运集装器规格 (ULD - Unit Load Devices)

空运 ULD 分为板 (Pallet) 和箱 (Container) 两大类，规格由 IATA 标准化。

| ULD 代码 | 类型 | 适用机型 | 外尺寸（底板 长×宽） | 最大容积 | 最大载重 | 特点 |
|---|---|---|---|---|---|---|
| PMC | 板 (Pallet) | B747/B777/A330 | 318 × 244 cm | 约 15 CBM | 6,800 kg | 主甲板标准板，使用最广 |
| PAG | 板 (Pallet) | B747/B777 | 318 × 244 cm | 约 15 CBM | 11,340 kg | 加重板，适合重货 |
| PLA | 板 (Pallet) | B747/A380 | 318 × 244 cm | 约 15 CBM | 6,800 kg | 带围网/围布板 |
| AKE (LD3) | 箱 (Container) | 腹舱/窄体机 | 156 × 153 cm | 约 4.3 CBM | 1,588 kg | 最常用腹舱集装箱 |
| AAA (LD1) | 箱 (Container) | 腹舱 | 156 × 153 cm | 约 5.0 CBM | 1,134 kg | 全高腹舱箱 |
| AMJ | 箱 (Container) | B747 主甲板 | 318 × 244 cm | 约 16.7 CBM | 6,800 kg | 主甲板封闭箱 |

---

## 6. 各运输模式业务特点对比

| 维度 | 海运 FCL | 海运 LCL | 空运 | 铁运（中欧班列） | 汽运（跨境卡车） | 跨境电商/FBA |
|---|---|---|---|---|---|---|
| **时效** | 3-38 天 | 7-45 天 | 1-10 天 | 7-18 天 | 1-7 天 | 5-50 天（视渠道） |
| **成本** | 最低 | 较低 | 最高 | 中等 | 中等偏高 | 视渠道而定 |
| **适用货量** | 大宗/大票 | 小票 | 急货/高值 | 中等货量 | 中小货量 | 小件/批量 |
| **核心单证** | MBL/HBL | MBL/HBL | MAWB/HAWB | 铁路运单 (CIM/SMGS) | CMR/TIR 运单 | 面单/清关资料 |
| **操作重点** | 订舱/装箱/报关 | CFS 操作/拼箱 | 安检/打板/配载 | 集结/换装/通关 | 口岸通关/配载 | 合规/清关/末端 |
| **核心风险** | 甩柜/滞期费 | 集货延误 | 拉货/安检拒收 | 口岸拥堵/制裁 | 证件逾期/事故 | IOR 失效/FBA 拒收 |
| **数字化工具** | AIS 船舶追踪 | — | e-AWB/PLACI | GPS 电子锁 | eTIR/e-CMR/GPS | 17Track/平台 API |
| **产品化程度** | 中等 | 较高 | 高 | 高 | 中等 | 极高 |
| **包舱/包板** | 包舱/BCO 合约 | N/A | 包板/包机 | 包班列/包箱 | 包车/专线 | N/A |

### 6.1 各运输模式时效深度参考 (Lead Time Reference)

时效受起运地、目的地、航线密度及转运环节影响。以下为中国出发至主要区域的 **港到港/站到站** 参考时效。

#### 6.1.1 海运 (Ocean Freight)
*含起运港截关至目的港到港时间*

| 航线 | 目的地示例 | 参考时效 (FCL) | 备注 |
|---|---|---|---|
| **近洋线** | 东南亚 (如胡志明/曼谷) | 3-7 天 | 班次频密，直航多 |
| **日韩线** | 东京/釜山 | 2-5 天 | 甚至可实现次日达 |
| **美西线** | 洛杉矶 (LAX) / 长滩 (LGB) | 12-18 天 | 快船 (如美森/以星) 最快 |
| **美东线** | 纽约 (NYC) / 萨凡纳 | 28-35 天 | 需经巴拿马运河或苏伊士运河 |
| **欧洲线** | 鹿特丹/汉堡/安特卫普 | 28-38 天 | 经苏伊士运河，受红海局势影响波动大 |
| **澳新线** | 悉尼/墨尔本 | 12-18 天 | 季节性运力调整较大 |

*注：LCL 拼箱通常需额外增加 3-5 天的集货与拆箱时间。*

#### 6.1.2 空运 (Air Freight)
*含入仓安检至目的港到货时间*

| 区域 | 参考时效 (Airport-to-Airport) | 备注 |
|---|---|---|
| **东南亚/日韩** | 1-2 天 | 窄体机、腹舱运力充足 |
| **北美/欧洲 (Base)** | 3-5 天 | 直飞 1 天，转运需 3-5 天 |
| **南美/非洲** | 5-10 天 | 需多次转运，中转时效不确定性高 |

#### 6.1.3 铁运 (Railway - CR Express)
*从班列发车至目的站到站时间*

| 目的地 | 参考时效 | 关键口岸 |
|---|---|---|
| **波兰 (马拉/罗兹)** | 12-15 天 | 中欧班列进入欧洲的第一站 |
| **德国 (汉堡/杜伊斯堡)** | 15-18 天 | 欧洲内陆分拨中心 |
| **中亚五国** | 7-12 天 | 霍尔果斯/阿拉山口出境 |

#### 6.1.4 汽运 (Cross-border Trucking)
*从装车发车至目的港到货时间*

| 目的地 | 参考时效 | 关键口岸 |
|---|---|---|
| **越南 (河内)** | 1-2 天 | 友谊关，适合急件及原材料 |
| **泰国 (曼谷)** | 3-5 天 | 经老挝转运，路况及通关影响大 |
| **中亚 (阿拉木图)** | 4-6 天 | 霍尔果斯，TIR 模式可加速 |

---

## 7. 行业标准组织

| 组织 | 英文全称 | 职能领域 | 核心规范/标准 |
|---|---|---|---|
| **IATA** | International Air Transport Association | 空运 | DGR (危险品)、e-AWB、PLACI、Cargo-XML、TACT 运价 |
| **IMO** | International Maritime Organization | 海运 | SOLAS (VGM)、IMDG Code (危险品)、ISM、ISPS |
| **UIC** | International Union of Railways | 铁运 | CIM/SMGS 统一运单、铁路联运技术标准 |
| **IRU** | International Road Transport Union | 汽运 | TIR 公约、eTIR 系统、国际公路运输资质 |
| **WCO** | World Customs Organization | 海关/合规 | HS 编码体系、AEO 互认框架、WCO SAFE 标准 |
| **FIATA** | International Federation of Freight Forwarders Associations | 货代行业 | FBL (FIATA 联运提单)、FCR (货运代理收据)、行业培训认证 |
