# 洞隐科技质量标准参考

**适用范围**: WMS、TMS、货代系统、航运系统等产品线
**版本**: 1.0
**更新日期**: 2026-03-25

---

## 目录

1. [代码标准](#1-代码标准)
2. [测试标准](#2-测试标准)
3. [质量门禁](#3-质量门禁)
4. [缺陷管理](#4-缺陷管理)
5. [性能标准](#5-性能标准)
6. [研发效能指标](#6-研发效能指标)

---

## 1. 代码标准

### 1.1 编码规范

#### 命名规范

| 类型 | 规范 | 示例 |
|------|------|------|
| 类名 (Class) | PascalCase | `WmsWarehouseManager`、`TmsDispatchEngine` |
| 函数/方法名 | camelCase | `calculateFreight()`、`validateBill()` |
| 常量名 | UPPER_SNAKE_CASE | `MAX_BATCH_SIZE = 1000` |
| 变量名 | camelCase | `warehouseId`、`shipmentStatus` |
| 文件名 (Module) | kebab-case | `freight-calculator.js`、`inventory-service.ts` |
| 数据库表名 | snake_case | `order_items`、`warehouse_location` |
| 数据库字段名 | snake_case | `created_at`、`warehouse_id` |

**原则**:
- 名称应具备自解释性，避免使用单字母变量 (i, j 仅用于循环计数器)
- 避免缩写，除非是行业通用缩写 (WMS、TMS、SKU、RF等)
- 中英文混用时，优先使用英文，中文注释补充说明

#### 注释规范

```javascript
/**
 * 波次计算引擎 - 将订单分配到拣货波次
 *
 * @param {Array<Order>} orders - 待分配订单列表
 * @param {Object} config - 波次配置 (最大行数、最大重量等)
 * @returns {Array<Wave>} 分配后的波次列表
 *
 * @example
 * const waves = calculateWaves(orders, { maxLines: 100, maxWeight: 500 });
 *
 * @throws {Error} 当订单数据不完整时抛出异常
 */
function calculateWaves(orders, config) {
  // 实现细节注释采用行注释
  // 关键业务逻辑需说明原因 Why，而非How
}
```

**注释要求**:
- 函数/方法必须有JSDoc注释，包含参数、返回值、异常说明
- 复杂业务逻辑需说明Why (业务原因)，非how (代码实现)
- TODO、FIXME、HACK注释需包含责任人和完成时间
- 避免过度注释，代码本身应该清晰易读

#### 代码结构

**文件组织**:
```
src/
├── modules/
│   ├── wms/
│   │   ├── domain/          # 领域模型
│   │   ├── services/        # 业务服务
│   │   ├── repositories/    # 数据访问
│   │   ├── controllers/     # 请求处理
│   │   └── __tests__/       # 单元测试
│   ├── tms/
│   └── ...
├── shared/                  # 共享工具、常量
├── config/                  # 配置管理
└── middleware/              # 中间件
```

**函数复杂度**:
- 圈复杂度 (Cyclomatic Complexity) ≤ 10
- 函数行数 ≤ 50 行 (核心算法可适当放宽)
- 嵌套层级 ≤ 3 层

### 1.2 代码评审 (Code Review) 标准

#### 审查清单

| 维度 | 检查项 | 说明 |
|------|--------|------|
| **功能正确性** | 逻辑是否正确 | 边界情况、空值处理 |
| | 需求理解 | 是否符合acceptance criteria |
| | 向后兼容性 | 是否破坏现有接口 |
| **代码质量** | 命名清晰度 | 是否遵循命名规范 |
| | 代码复杂度 | 圈复杂度、函数长度 |
| | DRY原则 | 是否存在代码重复 |
| | 异常处理 | 错误捕获、重试机制 |
| **测试覆盖** | 测试完整性 | 新增代码覆盖率 ≥80% |
| | 测试质量 | 是否覆盖边界和异常 |
| **性能表现** | 算法复杂度 | 是否存在性能隐患 |
| | 资源泄漏 | 内存、连接、文件句柄 |
| **安全性** | 输入验证 | SQL注入、XSS防护 |
| | 认证授权 | 权限检查、访问控制 |
| | 敏感信息处理 | 日志中是否包含密钥、密码 |

#### 评审流程

```
1. 开发者提交PR
   ↓
2. 自动检查 (CI/CD checks)
   - Lint/Format通过
   - 单元测试全绿
   - 覆盖率达标
   ↓
3. 指派审查人员 (Code Owner)
   - 同一产品线至少2人
   - 如涉及多产品线，对应Owner各1人
   ↓
4. 审查意见分类
   - APPROVED: 认可合并
   - CHANGES_REQUESTED: 需修改
   - COMMENTED: 建议/讨论
   ↓
5. 迭代修改 (若需要)
   ↓
6. 最终合并 (Merge)
```

**评审时间要求**:
- 小PR (≤200行): 12小时内完成评审
- 中等PR (200~500行): 24小时内完成评审
- 大PR (>500行): 分阶段评审，建议分解成多个小PR

#### 合并条件

- ✅ 至少2个Code Owner同意
- ✅ CI pipeline全部通过
- ✅ 测试覆盖率达标 (新增代码 ≥80%)
- ✅ 静态代码分析无新增高危/严重问题
- ✅ 无merge conflicts
- ✅ Commit记录规范 (参见1.4 Git提交规范)

### 1.3 静态代码分析

**工具配置**:
- **SonarQube**: 代码质量和安全性扫描
- **ESLint** (JavaScript/TypeScript): 代码风格、潜在问题
- **Spotbugs** (Java): 发现常见bug模式
- **SAST工具**: 安全漏洞检测 (如SonarQube Security标签)

**质量门禁设置** (Quality Gate):

| 指标 | 阈值 | 说明 |
|------|------|------|
| Bug数 | 0 | 新增bug不容许 |
| 代码异味 (Code Smell) | ≤5个 | 代码质量问题 |
| 覆盖率 (Coverage) | ≥80% | 新代码必须覆盖 |
| 重复代码率 (Duplication) | ≤5% | 避免代码重复 |
| Security Hotspots | 0 | 安全热点必须处理 |
| 高危问题 (Blocker) | 0 | 严重问题必须修复 |
| 严重问题 (Critical) | 0 | 不允许严重问题 |

**扫描时机**:
- 本地开发: `npm run lint` 或 `mvn sonar:sonar`
- 提交前: Git pre-commit hook执行扫描
- PR提交: 自动触发SonarQube扫描，gate检查阻塞合并
- 定期: 周报告和月度趋势分析

### 1.4 Git 提交规范

遵循 **Conventional Commits** 规范:

```
<type>(<scope>): <subject>

<body>

<footer>
```

**Type 类型**:

| 类型 | 说明 | 示例 |
|------|------|------|
| `feat` | 新功能 | `feat(wms): add wave calculation engine` |
| `fix` | 修复bug | `fix(tms): correct freight calculation logic` |
| `refactor` | 代码重构 (无功能变化) | `refactor(core): simplify order validation` |
| `test` | 测试相关 | `test(wms): add unit tests for inventory` |
| `docs` | 文档更新 | `docs: update API documentation` |
| `style` | 代码格式 (lint, format) | `style: format code with prettier` |
| `ci` | CI/CD配置变更 | `ci: update GitHub Actions workflow` |
| `chore` | 其他变更 (依赖更新等) | `chore: upgrade dependencies` |
| `perf` | 性能优化 | `perf(api): optimize database query` |

**Scope 范围**:
- 按产品线或模块划分: `wms`、`tms`、`freight`、`shipping`、`core`等
- 可选字段

**Subject 主题**:
- 使用英文，动词开头
- 使用现在式 ("add" 而非 "added")
- 首字母不大写
- 末尾不加句号
- 不超过50字符

**Body 体文**:
- 说明Why和What，非How
- 每行不超过72字符
- 可选字段

**Footer 页脚**:
```
Closes #123                  # 关闭相关Issue
Breaking Change: 描述变更    # 重大变更说明
Reviewed-by: @name          # 评审人
```

**提交示例**:

```
feat(wms): implement batch wave calculation

Add wave calculation algorithm for bulk order processing.
Supports constraints on max lines, max weight, and max pieces.

- Implements greedy algorithm for efficiency
- Performance target: < 30s for 1000 orders
- Includes comprehensive logging for debugging

Closes #456
Reviewed-by: @john.doe
```

---

## 2. 测试标准

### 2.1 测试金字塔 (Test Pyramid)

```
                △
               /|\
              / | \
             /  |  \ E2E Tests (5~10%)
            /   |   \
           /----+----\
          /     |     \
         /      |      \ Integration Tests (15~25%)
        /       |       \
       /--------+--------\
      /         |         \
     /          |          \ Unit Tests (60~75%)
    /____________|__________\

```

**测试分层**:

| 层级 | 占比 | 测试范围 | 执行速度 | 维护成本 |
|------|------|---------|---------|---------|
| **单元测试** | 60~75% | 单个函数/方法 | 很快 (ms) | 低 |
| **集成测试** | 15~25% | 模块间协作、API | 中等 (s) | 中 |
| **E2E测试** | 5~10% | 完整业务流程 | 较慢 (s~m) | 高 |

### 2.2 覆盖率要求

| 代码类型 | 覆盖率要求 | 说明 |
|---------|----------|------|
| 新增代码 | ≥80% | 强制门禁，不达标拒绝合并 |
| 核心模块 | ≥90% | WMS库存计算、TMS运费计算等 |
| 工具函数 | ≥85% | 共享库、通用函数 |
| 一般模块 | ≥75% | 普通业务模块 |
| 配置文件 | ≥70% | 可选，优先保证代码覆盖率 |

**覆盖率统计工具**:
- JavaScript/TypeScript: Jest、Istanbul
- Python: pytest-cov
- Java: JaCoCo
- 报告: SonarQube Dashboard

### 2.3 测试类型详解

#### 2.3.1 单元测试 (Unit Tests)

**测试对象**:
- 业务逻辑 (Calculator、Validator、Converter)
- 工具函数 (Utility Functions)
- 数据结构和算法

**编写原则**:
- 一个测试用例只测试一个功能点
- 遵循AAA模式: Arrange (准备) → Act (执行) → Assert (断言)
- 避免依赖外部服务，使用Mock/Stub

**示例**:
```javascript
describe('FreightCalculator', () => {
  describe('calculateFreight', () => {
    // 正常场景
    it('should calculate freight correctly for standard shipment', () => {
      const calculator = new FreightCalculator();
      const shipment = {
        weight: 100, // kg
        volume: 50,  // m³
        distance: 1000, // km
      };

      const result = calculator.calculateFreight(shipment);

      expect(result).toBe(500); // 预期运费
    });

    // 边界场景
    it('should handle zero weight shipment', () => {
      const calculator = new FreightCalculator();
      const result = calculator.calculateFreight({ weight: 0 });
      expect(result).toBe(0);
    });

    // 异常场景
    it('should throw error for negative weight', () => {
      const calculator = new FreightCalculator();
      expect(() => {
        calculator.calculateFreight({ weight: -10 });
      }).toThrow('Weight must be positive');
    });
  });
});
```

#### 2.3.2 集成测试 (Integration Tests)

**测试对象**:
- API接口 (HTTP requests/responses)
- 数据库操作 (增删改查事务)
- 跨模块协作

**编写原则**:
- 使用测试数据库或内存数据库 (H2、SQLite)
- 每个测试前后清理数据
- 测试真实的业务流程

**示例**:
```javascript
describe('OrderAPI - Integration Tests', () => {
  let db;

  beforeAll(async () => {
    db = await setupTestDatabase();
  });

  afterEach(async () => {
    await db.clearAllTables();
  });

  it('should create order and update inventory', async () => {
    const orderData = {
      customerId: '123',
      items: [
        { skuId: 'SKU001', quantity: 10 }
      ]
    };

    // Act: 创建订单
    const response = await request(app)
      .post('/api/orders')
      .send(orderData)
      .expect(201);

    const orderId = response.body.id;

    // Assert: 验证订单创建
    expect(response.body.status).toBe('PENDING');

    // Assert: 验证库存扣减
    const inventory = await db.query(
      'SELECT quantity FROM inventory WHERE sku_id = ?',
      ['SKU001']
    );
    expect(inventory[0].quantity).toBe(-10); // 库存减少
  });
});
```

#### 2.3.3 E2E测试 (End-to-End Tests)

**测试对象**:
- 完整业务流程 (订单→拣货→打包→发货)
- 用户界面交互
- 系统间集成

**覆盖范围**:
- WMS: 订单入库 → 波次计算 → 拣货 → 打包 → 出库
- TMS: 订单创建 → 运费计算 → 调度 → 发货 → 追踪
- 货代: 销售单 → 成本单 → 海运预订 → 应收应付
- 航运: 船期维护 → 舱位分配 → 装箱计划 → 提单生成

**工具**: Cypress、Selenium、Playwright

#### 2.3.4 性能测试 (Performance Tests)

**关键指标**:
- **响应时间**: API从请求到响应的时间
- **吞吐量**: 单位时间内的请求处理数
- **并发数**: 同时处理的用户/连接数
- **资源使用**: CPU、内存、磁盘、网络

**测试工具**: JMeter、Locust、K6

**示例场景**:
```
# WMS波次计算性能测试
场景: 高峰期处理1000个订单的波次计算
期望: 响应时间 < 30s，CPU < 80%，内存稳定

# TMS路线优化性能测试
场景: 同时处理100个调度任务
期望: 单个调度 < 1s，内存无泄漏
```

#### 2.3.5 安全测试 (Security Tests)

**OWASP Top 10 防护**:

| 威胁 | 测试方法 | 防护措施 |
|------|---------|---------|
| SQL注入 | 输入特殊字符: `' OR '1'='1` | 使用参数化查询、ORM框架 |
| XSS攻击 | 输入脚本标签: `<script>alert()</script>` | 输出转义、CSP策略 |
| 认证绕过 | 修改token、会话ID | 强token验证、安全存储 |
| 敏感信息泄露 | 检查日志、错误消息 | 脱敏日志、安全响应 |
| 访问控制 | 尝试越权操作 | RBAC权限检查 |

### 2.4 物流软件特有测试

#### WMS (仓库管理系统)

**RF扫码准确性**:
```
用例1: 扫描SKU条形码
- 验证: 对应的SKU信息正确加载
- 边界: 无效条码、损坏条码识别

用例2: 分货到位置
- 验证: 库位信息准确，库存增加
- 边界: 库位不存在、库位已满处理

用例3: 拣货确认
- 验证: 拣货数量与订单匹配
- 异常: 数量不符、SKU错误时的处理
```

**库存计算精度**:
```
测试场景:
1. 库存初始化精度
2. 收货、发货、移库、盘点后的库存精度
3. 多并发操作下的库存一致性
4. 库存负数、库存溢出的处理

精度要求:
- 库存数量精度: 整数级别
- 库存金额精度: 0.01元级别
```

#### TMS (运输管理系统)

**运费计算规则**:
```
测试维度:
1. 计费要素完整性
   - 重量、体积、距离、时间段
   - 货物类型、运输方式

2. 计费逻辑准确性
   - 抛货判断: max(weight, volume/6000)
   - 阶梯价格: 不同重量段不同单价
   - 折扣应用: 按客户等级、订单量应用折扣

3. 多币种处理
   - 汇率换算精度 (0.0001)
   - 四舍五入规则一致性

4. 异常场景
   - 缺少必要参数
   - 计费公式异常
```

**调度算法**:
```
测试验证:
1. 路线最优性
   - 最短路径验证
   - 成本最低验证

2. 约束满足
   - 车辆容量、重量限制
   - 配送时间窗口
   - 司机工作时间

3. 性能要求
   - 50个订单调度 < 5s
   - 200个订单调度 < 30s

4. 并发测试
   - 多个调度任务同时处理
```

#### 货代系统 (Forwarding)

**多币种换算精度**:
```
测试场景:
1. 汇率维护与更新
   - 汇率精度 (4位小数)
   - 汇率生效时间

2. 成本计算精度
   - 采购价 × 汇率 = 成本价
   - 精度要求: 0.01元

3. 销售报价
   - 成本价 × 利率 = 销售价
   - 利率应用的正确性

4. 应收应付核算
   - 使用实际汇率 vs 记账汇率
   - 汇兑损益计算
```

**单证格式合规**:
```
验证的单证类型:
1. 提单 (B/L)
   - 格式: 国际标准FIATA格式
   - 必填项: 船公司、船名、航次、目的地
   - 条款: Free Time、备注条款

2. 发票 (Invoice)
   - 格式: 国际商业发票格式
   - HS编码有效性
   - 计价单位标准化

3. 报关单
   - 海关系统接口格式
   - 商品编码、价格申报要求

4. 装箱单 (Packing List)
   - 包装信息准确性
   - 与发票、提单数据一致
```

#### 航运系统 (Shipping)

**船期计算**:
```
计算逻辑:
1. 基础船期维护
   - 出发港、目的港、船期
   - Transit Time计算 (日期差)

2. 截关时间 (Cut-off)
   - 通常为开船前48小时
   - 不同货物类型可有不同截关

3. 舱位可用性
   - 总容量 - 已订舱 = 可订舱
   - 重量、TEU容量双重约束

4. 异常处理
   - 船期取消、延误
   - 自动更新相关订舱单
```

**舱位分配逻辑**:
```
分配原则:
1. 优先级排序
   - 合作年限、历史订舱量
   - 订舱时间顺序

2. 约束条件
   - 单个客户最大预订比例 (如30%)
   - 小单整合规则
   - 特殊货物舱位预留

3. 确认流程
   - 舱位预留 → 客户确认 → 正式订舱
   - 超期自动释放 (如超过2天未确认)

4. 变更管理
   - 增加舱位: 通知仓库补充
   - 取消舱位: 计算违约金
   - 舱位转让: 审批流程
```

---

## 3. 质量门禁 (Quality Gates)

### 3.1 提交门禁 (Commit Gates)

代码提交前必须通过以下检查:

```bash
# 本地执行 (Git Pre-commit Hook)
$ git commit

✓ Lint检查 (ESLint)
✓ 格式检查 (Prettier)
✓ 类型检查 (TypeScript)
✓ 单元测试 (Jest, 新增代码必须有测试)
✓ 提交信息规范 (Conventional Commits)

若任何检查失败，拒绝提交
```

**检查项**:

| 检查项 | 工具 | 失败处理 |
|--------|------|---------|
| 代码格式 | Prettier | 自动修复或拒绝 |
| Lint规则 | ESLint | 拒绝提交 |
| 类型检查 | TypeScript | 拒绝提交 |
| 单元测试 | Jest | 拒绝提交 (覆盖率<80%) |
| 提交信息 | Commitlint | 拒绝提交 |

### 3.2 合并门禁 (Merge Gates)

**PR合并条件** (必须全部满足):

```
□ Code Review 通过
  - 至少2个Code Owner同意 (APPROVED)
  - 无 CHANGES_REQUESTED 状态

□ CI Pipeline 全绿
  - 所有自动化测试通过
  - 代码覆盖率达标 (≥80%)
  - 静态代码分析门禁通过

□ 测试覆盖率达标
  - 新增代码覆盖率 ≥80%
  - 核心模块覆盖率 ≥90%

□ 静态代码分析通过
  - SonarQube 门禁通过
  - 无新增高危/严重问题
  - Security Hotspots已处理

□ 无冲突
  - 无merge conflicts
  - 基于最新main分支

□ Commit规范
  - 遵循Conventional Commits
  - Commit message有意义
```

### 3.3 发版门禁 (Release Gates)

**发版前必须验证**:

| 验证项 | 要求 | 说明 |
|--------|------|------|
| **回归测试** | 全部通过 | 关键业务流程必须测试 |
| **性能测试** | 达标 | P95响应时间、并发数 |
| **安全扫描** | 无高危漏洞 | SAST扫描通过 |
| **文档更新** | 完整 | API文档、变更日志 |
| **数据库迁移** | 测试通过 | 不可逆操作需双人审核 |
| **灰度计划** | 制定 | 新版本上线策略 |
| **回滚方案** | 备妥 | 故障快速回滚流程 |

**发版检查清单**:

```
发版前 Check List:

【功能验收】
- [ ] 产品经理验收功能完整性
- [ ] 所有acceptance criteria通过

【质量检查】
- [ ] 测试覆盖率达标
- [ ] 性能测试通过
- [ ] 安全扫描无高危问题
- [ ] 代码审查全部通过

【部署准备】
- [ ] 发版说明已编写
- [ ] 数据库迁移脚本已验证
- [ ] 灰度发版计划已确认
- [ ] 运维人员已参与评审

【上线执行】
- [ ] 备份已确认
- [ ] 监控告警已就绪
- [ ] 值班人员已安排
- [ ] 回滚方案已确认
```

---

## 4. 缺陷管理

### 4.1 缺陷分级

| 级别 | 优先级 | 影响范围 | 处理时限 | 示例 |
|------|--------|---------|---------|------|
| **P0** | 立即 | 系统故障 | 1小时 | 库存数据全部丢失、无法登录 |
| **P1** | 高 | 核心功能不可用 | 4小时 | WMS波次计算崩溃、TMS无法调度 |
| **P2** | 中 | 功能受限 | 24小时 | 部分客户无法下单、运费计算偶发错误 |
| **P3** | 低 | 体验问题 | 7天 | UI显示问题、提示信息不准确 |

### 4.2 缺陷生命周期

```
     New (新建)
       ↓ 开发评估
   Confirmed (已确认)
       ↓ 指派给开发
    Assigned (已指派)
       ↓ 修复代码
     Fixed (已修复)
       ↓ 测试验证
    Verified (已验证)
       ↓ 发版上线
     Closed (已关闭)

异常路径:
- Not a Bug (非缺陷) - 工作正常
- Duplicate (重复) - 与其他缺陷重复
- Deferred (延期) - 推到下一个版本
- Cannot Reproduce (无法复现) - 信息不足
```

**各状态定义**:

| 状态 | 定义 | 操作权限 |
|------|------|---------|
| **New** | 缺陷刚提交 | QA、任何人 |
| **Confirmed** | QA验证确认缺陷存在 | QA |
| **Assigned** | 指派给开发者修复 | QA、PM |
| **Fixed** | 开发完成、提交PR | 开发者 |
| **Verified** | 测试验证修复正确 | QA |
| **Closed** | 缺陷已发版关闭 | QA、发版管理员 |

### 4.3 缺陷密度指标

**计算公式**:

```
缺陷密度 = 缺陷数量 / 代码行数 (KLOC)

示例:
- 500行代码, 发现5个缺陷
- 缺陷密度 = 5 / 0.5 = 10 个/千行
```

**目标值**:

| 产品阶段 | 缺陷密度 | 说明 |
|---------|---------|------|
| 灰度测试 (Alpha) | < 15/KLOC | 接受度较高 |
| 公测 (Beta) | < 10/KLOC | 需要人工测试 |
| 正式发版 (GA) | < 5/KLOC | 高质量要求 |
| 稳定版本 | < 2/KLOC | 生产环境 |

**监控**: 每周统计缺陷数量、密度趋势，作为质量评估指标

### 4.4 缺陷逃逸率控制

**定义**: 逃逸到用户端的缺陷占比

```
逃逸率 = 用户发现的缺陷数 / (内部发现 + 用户发现)

示例:
- 内部发现100个缺陷，用户发现5个
- 逃逸率 = 5 / (100 + 5) = 4.76%
```

**目标**: 逃逸率 < 2%

**降低措施**:
1. 提升测试覆盖率和深度
2. 强化测试用例评审
3. 建立缺陷预防机制 (根本原因分析)
4. 灰度发版，监控告警

---

## 5. 性能标准

### 5.1 API响应时间

**分级标准**:

| 服务类型 | P50 | P95 | P99 | 说明 |
|---------|-----|-----|-----|------|
| **简单查询** | <100ms | <200ms | <500ms | 单表查询、缓存命中 |
| **常规查询** | <200ms | <500ms | <1s | 简单关联查询、单次RPC |
| **复杂查询** | <500ms | <2s | <5s | 多表关联、复杂计算 |
| **聚合服务** | <1s | <3s | <10s | 多个下游依赖 |

**监控指标**:
- P50 (中位数): 一半请求快于此值
- P95 (95分位): 5%请求慢于此值 ⚠️ **重点监控**
- P99 (99分位): 1%请求慢于此值

**优化策略**:
- 数据库索引优化
- 缓存 (Redis、内存缓存)
- 异步处理、消息队列
- 服务分拆、水平扩展

### 5.2 页面加载性能

**核心Web指标 (Core Web Vitals)**:

| 指标 | 阈值 | 说明 |
|------|------|------|
| **FCP** (First Contentful Paint) | < 1.5s | 首次内容绘制时间 |
| **LCP** (Largest Contentful Paint) | < 2.5s | 最大内容绘制时间 |
| **CLS** (Cumulative Layout Shift) | < 0.1 | 布局偏移量 |

**其他性能指标**:

| 指标 | 目标 | 说明 |
|------|------|------|
| **TTI** (Time to Interactive) | < 3.5s | 页面可交互时间 |
| **FID** (First Input Delay) | < 100ms | 首次输入延迟 |
| **TTFB** (Time to First Byte) | < 600ms | 首字节返回时间 |

**前端优化**:
- 代码分割、Tree-shaking
- 图片优化、懒加载
- CSS/JS压缩、CDN加速
- 减少DOM元素、重排重绘

### 5.3 并发支持

**设计容量**:

| 产品线 | 目标并发数 | 说明 |
|--------|----------|------|
| **WMS** | 500~1000 | 仓库运营人员、RF终端 |
| **TMS** | 300~500 | 调度人员、司机端 |
| **货代** | 200~300 | 销售、操作人员 |
| **航运** | 100~200 | 预订、单证操作 |

**压力测试要求**:
- 负载测试: 逐步增加并发，找到性能拐点
- 压力测试: 超过设计容量20%，观察系统行为
- 峰值测试: 模拟突发流量

### 5.4 物流场景性能

#### WMS性能指标

```
【波次计算】
- 1000单: < 30s
- 5000单: < 120s (可异步处理)
- 性能优化: 批处理、多线程、算法优化

【库存查询】
- 单SKU精确查询: < 50ms (Redis缓存)
- 多SKU查询 (10个): < 200ms
- 库位查询 (1000+库位): < 300ms

【拣货单生成】
- 单次波次 (100行): < 1s
- 批量生成 (10个波次): < 5s

【数据同步】
- RF终端与后台同步: < 5s
- 库存实时更新: < 100ms
```

#### TMS性能指标

```
【运费计算】
- 单个订单: < 100ms
- 批量计算 (100个): < 1s
- 缓存命中率: > 90% (基于历史路线)

【调度排线】
- 50个订单: < 5s
- 100个订单: < 15s
- 200个订单: < 60s
- 并发调度 (5个同时): 响应时间线性增长

【路线优化】
- 算法收敛时间: < 30s
- 优化效果: 路线成本降低5~10%
```

#### 货代系统性能指标

```
【成本计算】
- 单个成本单: < 200ms
- 批量导入 (1000条): < 5s

【销售报价】
- 实时报价生成: < 500ms
- 历史价格查询: < 200ms (缓存)

【单证处理】
- 提单生成: < 2s
- 装箱单生成: < 1s
- 批量打印 (100份): < 10s
```

#### 航运系统性能指标

```
【船期查询】
- 查询可用船期: < 300ms (缓存)
- 查询近30天船期: < 1s

【舱位分配】
- 分配单个舱位: < 100ms
- 分配多个舱位 (50个): < 5s
- 验证舱位可用性: < 200ms

【预订单处理】
- 生成预订单: < 500ms
- 批量导入预订 (100): < 30s
```

---

## 6. 研发效能指标

### 6.1 Sprint Velocity (冲刺速度)

**定义**: 团队在一个Sprint (通常2周) 内完成的用户故事点数

**计算**:

```
Velocity = 本Sprint完成的故事点数 / Sprint时长 (周)

示例:
- Sprint完成30个故事点
- Sprint时长2周
- Velocity = 30 / 2 = 15点/周
```

**监控目标**:
- Velocity稳定性: 变化在±20%以内
- 趋势: 逐步上升 (优化流程、降低阻塞)
- 预测准确性: 实际完成 > 承诺完成的90%

**影响因素**:
- 团队规模变化
- 人员请假、新人培养
- 外部依赖阻塞
- 技术债积累

### 6.2 代码变更频率

| 指标 | 目标 | 说明 |
|------|------|------|
| **提交频率** | 日均3~5次 | 小粒度提交，便于追踪 |
| **PR提交频率** | 日均2~3个 | 定期推送，避免长期分支 |
| **代码行数变化** | 周均+500行 | 业务功能增长 |
| **文件变更数** | PR均值10~20个 | 代码内聚性指标 |

**质量指标**:
- PR中文件变更数 > 50: 建议分拆
- 单个文件增删 > 500行: 考虑重构

### 6.3 部署频率 (Deployment Frequency)

| 环境 | 目标频率 | 说明 |
|------|---------|------|
| **开发环境** | 日均5~10次 | 开发测试 |
| **测试环境** | 日均1~3次 | 功能测试 |
| **灰度环境** | 周均1~2次 | 灰度验证 |
| **生产环境** | 周均1~2次 | 正式发版 |

**优化目标**: 从周发版 → 日发版 (成熟团队)

### 6.4 变更失败率 (Change Failure Rate)

**定义**: 导致生产故障的变更占比

```
CFR = 产生故障的变更数 / 总变更数

示例:
- 周发版3次，其中1次导致故障
- CFR = 1 / 3 = 33.3%

目标: CFR < 15% (优秀: < 5%)
```

**降低措施**:
- 强化代码审查、测试覆盖
- 灰度发版策略
- 发版自动化、减少人工操作
- 完善监控告警

### 6.5 平均恢复时间 (MTTR, Mean Time To Recover)

**定义**: 从故障发现到恢复的平均时间

```
MTTR = 故障修复总时间 / 故障总数

示例:
- 月内4次故障，总恢复时间4小时
- MTTR = 4h / 4 = 1小时

目标: MTTR < 30分钟
```

**改进方向**:
- 快速故障定位 (完善日志、监控)
- 自动化回滚能力
- 团队应急响应能力
- 故障根因分析

### 6.6 DORA指标 (DevOps Research and Assessment)

Google提出的研发效能四个关键指标:

| 指标 | 说明 | 目标 (高绩效) |
|------|------|--------------|
| **部署频率** | 多久部署一次 | 日均1次以上 |
| **前置时间** | 从代码提交到部署的时间 | < 1小时 |
| **故障恢复时间** | MTTR | < 1小时 |
| **变更失败率** | CFR | < 15% |

**绩效分级**:

```
【高绩效 Elite】
- 部署频率: 日均多次
- 前置时间: < 1小时
- MTTR: < 1小时
- CFR: < 15%

【高绩效 High】
- 部署频率: 周均1~3次
- 前置时间: 1小时~1天
- MTTR: 1小时~1天
- CFR: 15~30%

【中等绩效 Medium】
- 部署频率: 月均1~3次
- 前置时间: 1天~1周
- MTTR: 1天~7天
- CFR: 30~45%

【低绩效 Low】
- 部署频率: 6个月~1年
- 前置时间: > 1个月
- MTTR: > 1个月
- CFR: > 45%
```

**团队目标**: 争取达到High绩效水平，逐步向Elite靠近

---

## 附录

### 常用命令

```bash
# 代码检查
npm run lint              # ESLint检查
npm run format            # Prettier格式化
npm run type-check        # TypeScript类型检查

# 测试执行
npm run test              # 运行单元测试
npm run test:coverage     # 生成覆盖率报告
npm run test:integration  # 运行集成测试

# 代码质量
npm run sonar             # SonarQube扫描
npm run security-check    # 安全扫描

# 提交前检查
npm run pre-commit        # 等同于Git pre-commit hook
```

### 相关工具链

| 功能 | 工具 | 用途 |
|------|------|------|
| 代码检查 | ESLint | 风格检查、bug检测 |
| 代码格式 | Prettier | 自动格式化 |
| 类型检查 | TypeScript | 静态类型检查 |
| 测试框架 | Jest | 单元&集成测试 |
| E2E测试 | Cypress | 页面交互测试 |
| 质量平台 | SonarQube | 代码质量、安全 |
| 性能测试 | JMeter | 负载测试、性能监测 |
| CI/CD | GitHub Actions | 自动化流程 |

---

**文档维护人员**: 质量保障部门
**最后更新**: 2026-03-25
**下次评审**: 2026-06-25
