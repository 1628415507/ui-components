---
name: product-development
description: >
  洞隐科技自研产品（WMS/TMS/货代系统/航运系统）的 Scrum 敏捷研发管理 Skill。
  覆盖产品规划、需求管理、Sprint 迭代、技术方案评审、测试质量保障、版本发布和线上运维的完整研发生命周期。
  每当用户提到"产品需求"、"PRD"、"版本规划"、"Roadmap"、"Sprint"、"迭代"、"站会"、
  "评审"、"回顾"、"技术方案"、"代码评审"、"Code Review"、"测试策略"、"发版"、"上线"、
  "灰度发布"、"版本说明"、"Release Notes"、"故障响应"、"线上问题"、"技术债务"、
  "产品Backlog"、"用户故事"、"验收标准"时，必须使用此 skill。
  也适用于用户说"下个版本做什么"、"这个Sprint排什么"、"发版前检查"、"线上出问题了"、
  "帮我写PRD"、"技术评审怎么做"等隐含产品研发管理的场景。
  注意与 implementation-delivery skill 的区别：本 skill 管理的是洞隐自研产品的版本迭代研发，
  implementation-delivery 管理的是将产品交付给客户的实施项目。两者是上下游关系：
  产品研发产出标准产品版本 → 实施交付将产品部署到客户现场。
  Make sure to use this skill whenever the user needs help with product development,
  sprint planning, version release, technical review, or any R&D workflow for Deep Insights'
  own products, even if they don't explicitly mention "研发" or "product development".
---

# 产品研发管理 Skill

洞隐科技（Deep Insights）自研产品的 Scrum 敏捷研发管理工具。适用于 WMS、TMS、货代系统、航运系统四大产品线的版本迭代研发。

## 定位与边界

**本 Skill 管理**: 洞隐自研产品的需求规划、迭代开发、测试、发布、运维
**implementation-delivery 管理**: 将产品交付给客户的实施项目

**衔接点**:
- 实施项目中发现的产品 Bug → 进入产品 Backlog
- 实施项目中的通用定制需求 → 评估后纳入产品版本规划
- 产品新版本发布 → 通知实施团队，更新实施文档和培训材料

## 意图识别与响应策略

### 场景 A：产品规划与需求管理
**触发**: "版本规划"、"Roadmap"、"下个版本做什么"、"PRD"、"产品需求"、"Backlog"
**动作**:
1. 确认产品线（WMS/TMS/货代/航运）
2. 根据请求类型：
   - 写PRD → 读取 `templates/prd.md`，引导用户按模板编写
   - 版本规划 → 读取 `references/scrum-framework.md` 中的规划章节，引导梳理版本目标和范围
   - Backlog 管理 → 帮助用户梳理和优先级排序（RICE/MoSCoW）

### 场景 B：Sprint 迭代管理
**触发**: "Sprint计划"、"迭代"、"站会"、"Sprint评审"、"回顾会"、"燃尽图"
**动作**:
1. 读取 `references/scrum-framework.md` 中的 Sprint 管理章节
2. 根据请求：
   - Sprint 计划 → 读取 `templates/sprint-plan.md`，引导制定 Sprint 目标、选择 Backlog 项、评估故事点
   - 站会模板 → 提供"昨天/今天/阻碍"结构
   - Sprint 评审 → 帮助准备 Demo 清单
   - 回顾会 → 引导"继续做/停止做/开始做"结构化回顾

### 场景 C：技术方案与代码评审
**触发**: "技术方案"、"架构设计"、"Code Review"、"代码评审"、"技术评审"
**动作**:
1. 读取 `templates/technical-design.md` 帮助编写技术方案
2. 读取 `references/quality-standards.md` 中的代码评审标准
3. 提供评审检查清单

### 场景 D：测试与质量保障
**触发**: "测试策略"、"自动化测试"、"回归测试"、"缺陷分析"、"质量门禁"
**动作**:
1. 读取 `references/quality-standards.md`
2. 根据请求提供测试策略建议、质量门禁标准、缺陷分析框架

### 场景 E：版本发布
**触发**: "发版"、"发布计划"、"灰度"、"版本说明"、"Release Notes"、"发版检查"
**动作**:
1. 读取 `references/release-process.md`
2. 根据请求：
   - 发布计划 → 读取 `templates/release-plan.md`
   - 版本说明 → 读取 `templates/release-notes.md`，帮助生成结构化的版本说明
   - 发版检查 → 提供发版前检查清单

### 场景 F：线上运维与故障响应
**触发**: "线上问题"、"故障"、"P0/P1"、"复盘"、"监控告警"
**动作**:
1. 读取 `references/release-process.md` 中的故障响应章节
2. 根据严重程度引导处理流程
3. 故障后引导复盘

### 场景 G：研发效能
**触发**: "技术债务"、"研发效率"、"Sprint 速率"、"代码质量"
**动作**:
1. 读取 `references/quality-standards.md` 中的效能指标章节
2. 提供度量框架和改进建议

## 参考文档

| 文件 | 内容 | 何时读取 |
|------|------|----------|
| `references/scrum-framework.md` | Scrum 敏捷框架、角色、仪式、工件 | Sprint 管理、产品规划 |
| `references/release-process.md` | 版本发布流程、灰度策略、故障响应 | 发版、上线、线上问题 |
| `references/quality-standards.md` | 代码标准、测试标准、质量门禁、效能指标 | 代码评审、测试、质量管理 |

## 可用模板

### 需求与规划
| 模板文件 | 用途 |
|----------|------|
| `templates/prd.md` | 产品需求文档 — 需求背景、用户故事、验收标准、原型 |
| `templates/sprint-plan.md` | Sprint 计划 — 目标、Backlog 选择、任务分解、容量评估 |

### 技术设计
| 模板文件 | 用途 |
|----------|------|
| `templates/technical-design.md` | 技术方案文档 — 架构设计、详细设计、风险评估 |

### 发布与运维
| 模板文件 | 用途 |
|----------|------|
| `templates/release-plan.md` | 发布计划 — 版本范围、发布步骤、回退方案、验证清单 |
| `templates/release-notes.md` | 版本说明 — 新功能、优化、修复、已知问题、升级指南 |

## 与钉钉生态的协同

### Sprint 仪式
- 建议使用 `dingtalk-calendar` 创建 Sprint 计划会、评审会、回顾会的固定日程
- 建议使用 `dingtalk-todo` 将 Sprint Backlog 项创建为待办

### 发版通知
- 建议使用 `dingtalk-group-robot` 向研发群推送版本发布通知
- 建议使用 `dingtalk-notify` 通知实施团队新版本已发布

### 故障响应
- 建议使用 `dingtalk-notify` 发送故障通知和升级信息
- 建议使用 `dingtalk-group-robot` 在值班群推送故障状态更新

## 与 implementation-delivery 的联动

当以下场景出现时，提示用户两个 Skill 之间的衔接：
- 实施团队反馈产品 Bug → 建议录入产品 Backlog 并标记来源
- 通用定制需求产品化 → 建议写 PRD 纳入版本规划
- 新版本发布 → 建议通知实施团队，提供升级说明
- 产品文档更新 → 建议同步更新实施交付物模板

## 文档生成原则

1. **Scrum 语言**: 使用标准 Scrum 术语（Product Backlog、Sprint、Story Point 等），首次出现时附中文释义
2. **产品线区分**: 不同产品线的 PRD 需包含该产品线的领域上下文
3. **可追溯性**: 需求 → 设计 → 代码 → 测试 → 发布的全链路可追溯
4. **格式选择**: PRD 和技术方案生成 docx，Sprint 计划和版本说明可用 md
5. **面向团队**: 文档的读者是研发团队内部成员，语言可以更技术化
